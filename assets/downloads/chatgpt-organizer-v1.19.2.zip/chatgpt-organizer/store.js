// Shared storage helper. Data shape kept intentionally simple and portable:
// {
//   folders: { [folderId]: { id, name, parentId } },   // parentId null = top level
//   chats:   { [chatId]:   { id, title, folderId, createTime } } // folderId null = Unorganized
// }

const STORE_KEY = "cgpt_organizer_data_v1";

function emptyData() {
  return { folders: {}, chats: {} };
}

async function loadData() {
  const res = await chrome.storage.local.get(STORE_KEY);
  const data = res[STORE_KEY];
  if (!data) return emptyData();
  if (!data.folders) data.folders = {};
  if (!data.chats) data.chats = {};
  return data;
}

async function saveData(data) {
  await chrome.storage.local.set({ [STORE_KEY]: data });
}

function newId(prefix) {
  return prefix + "_" + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

// Extract a conversation id from a chatgpt.com / chat.openai.com URL, e.g.
// https://chatgpt.com/c/6714e2b0-xxxx-xxxx-xxxx-xxxxxxxxxxxx
function extractConversationId(url) {
  if (!url) return null;
  const match = url.match(/\/c\/([a-zA-Z0-9-]+)/);
  return match ? match[1] : null;
}

function isChatGptUrl(url) {
  return !!url && (url.includes("chatgpt.com") || url.includes("chat.openai.com"));
}

const LAST_BACKUP_KEY = "cgpt_organizer_last_backup";

async function getLastBackupTime() {
  const res = await chrome.storage.local.get(LAST_BACKUP_KEY);
  return res[LAST_BACKUP_KEY] || null;
}

async function setLastBackupTime(ts) {
  await chrome.storage.local.set({ [LAST_BACKUP_KEY]: ts });
}

const PROJECT_PREFIXES_KEY = "cgpt_organizer_project_prefixes";

async function getProjectPrefixes() {
  const res = await chrome.storage.local.get(PROJECT_PREFIXES_KEY);
  return Array.isArray(res[PROJECT_PREFIXES_KEY]) ? res[PROJECT_PREFIXES_KEY] : [];
}

async function setProjectPrefixes(list) {
  await chrome.storage.local.set({ [PROJECT_PREFIXES_KEY]: list });
}

const SORT_PREFS_KEY = "cgpt_organizer_sort_prefs";
const DEFAULT_SORT_PREFS = { chatSort: "date_desc", folderSort: "name_asc" };

async function getSortPrefs() {
  const res = await chrome.storage.local.get(SORT_PREFS_KEY);
  return Object.assign({}, DEFAULT_SORT_PREFS, res[SORT_PREFS_KEY] || {});
}

async function setSortPrefs(prefs) {
  await chrome.storage.local.set({ [SORT_PREFS_KEY]: prefs });
}

const BACKUP_DISMISS_KEY = "cgpt_organizer_backup_dismiss_until";

async function getBackupDismissUntil() {
  const res = await chrome.storage.local.get(BACKUP_DISMISS_KEY);
  return res[BACKUP_DISMISS_KEY] || 0;
}

async function setBackupDismissUntil(ts) {
  await chrome.storage.local.set({ [BACKUP_DISMISS_KEY]: ts });
}

// ---------- Full-conversation export ----------
// Three sources, tried in order by the organizer's "Export current chat" button:
//   1. fetchConversationViaPage — reads the conversation JSON from inside your open, signed-in
//      ChatGPT tab, the same read the page itself does to display the chat. Read-only: it
//      never sends messages or clicks anything. If ChatGPT ever answers with a challenge or
//      error instead of data, we do NOT try to work around it — we just fall through to (2).
//   2. extractPageMessages — reads the rendered text off the open chat (or share) page.
//   3. Your official export file (conversations.json) — slowest, but always complete.
// Sources 1 and 3 return the same JSON shape (mapping / current_node), parsed below.

// ---------- Transcript cleanup ----------
// ChatGPT's replies can contain its own UI markup (<box>, <row>, <AsyncImage/>, <Cite/>,
// <Entity/>, <WritingBlock>, {@body ...} state lines, etc.) that the ChatGPT app renders as
// cards and widgets. In a .txt transcript that's noise, so we convert it back to plain text.
// Only a fixed list of known tag names is touched, and fenced ``` code blocks are left as-is,
// so ordinary HTML/JSX that you or ChatGPT wrote as code survives untouched.

const GENUI_DROP = new Set(["asyncimage", "cite", "memorycite", "icon", "divider", "spacer", "image", "img", "button"]);
const GENUI_UNWRAP = new Set(["box", "row", "col", "stack", "grid", "text", "title", "radio-group", "card", "section"]);
const GENUI_ALL = new Set([...GENUI_DROP, ...GENUI_UNWRAP, "entity", "link", "badge", "radio", "writingblock"]);

function decodeHtmlEntities(s) {
  const named = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " " };
  return s.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, code) => {
    if (code[0] === "#") {
      const n = code[1].toLowerCase() === "x" ? parseInt(code.slice(2), 16) : parseInt(code.slice(1), 10);
      return Number.isFinite(n) ? String.fromCodePoint(n) : m;
    }
    return named[code.toLowerCase()] ?? m;
  });
}

// Scans one tag starting at s[i] === "<". Handles quoted attrs and {...} attrs that may
// themselves contain ">" (e.g. onClick={() => ...}). Returns null if it isn't a known tag.
function readGenUiTag(s, i) {
  const m = /^<(\/?)([A-Za-z][\w-]*)/.exec(s.slice(i, i + 40));
  if (!m) return null;
  const name = m[2].toLowerCase();
  if (!GENUI_ALL.has(name)) return null;
  let j = i + m[0].length, depth = 0, quote = null;
  for (; j < s.length; j++) {
    const c = s[j];
    if (quote) { if (c === quote) quote = null; continue; }
    if (c === '"' || c === "'") { if (depth === 0) quote = c; continue; }
    if (c === "{") depth++;
    else if (c === "}") depth--;
    else if (c === ">" && depth <= 0) break;
  }
  if (j >= s.length) return null;
  const raw = s.slice(i, j + 1);
  return { name, closing: m[1] === "/", selfClosing: /\/\s*>$/.test(raw), raw, end: j + 1 };
}

function attr(raw, key) {
  const m = new RegExp(`\\b${key}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|\\{\\s*"([^"]*)"\\s*\\})`).exec(raw);
  return m ? (m[1] ?? m[2] ?? m[3]) : null;
}

function cleanGenUiSegment(s) {
  // Drop {@body ...} state declarations (whole line).
  s = s.replace(/^[ \t]*\{@body[^\n]*\}[ \t]*$/gm, "");

  let out = "";
  let skipUntilClose = null; // tag name whose inner content is being dropped (e.g. button)
  let i = 0;
  while (i < s.length) {
    if (s[i] !== "<") {
      if (!skipUntilClose) out += s[i];
      i++;
      continue;
    }
    const tag = readGenUiTag(s, i);
    if (!tag) { if (!skipUntilClose) out += s[i]; i++; continue; }
    i = tag.end;

    if (skipUntilClose) {
      if (tag.closing && tag.name === skipUntilClose) skipUntilClose = null;
      continue;
    }
    if (tag.closing) {
      if (tag.name === "writingblock") out += "\n\uE002\n";
      else if (tag.name === "badge") out += "]";
      else if (tag.name === "title") out += "\n";
      continue;
    }
    switch (tag.name) {
      case "entity": out += attr(tag.raw, "value") || ""; break;
      case "link": {
        const url = attr(tag.raw, "url"), title = attr(tag.raw, "title");
        out += title && url ? `${title} (${url})` : (title || url || "");
        break;
      }
      case "writingblock": out += "\n\uE000\uE001\n"; break;
      case "badge": out += "["; if (tag.selfClosing) out += "]"; break;
      case "radio": out += "\n- "; break;
      case "title": out += "\n"; break;
      default:
        if (GENUI_DROP.has(tag.name) && !tag.selfClosing) skipUntilClose = tag.name;
        // unwrap/drop tags otherwise just disappear
    }
  }
  return out;
}

function cleanMessageText(text) {
  if (!text) return text;
  text = text.replace(/[\uE000-\uE002]/g, ""); // reserved for our own document markers
  // Split out fenced code blocks so they're never altered.
  const pieces = text.split(/(```[\s\S]*?```)/g);
  const cleaned = pieces.map((piece, idx) => {
    if (idx % 2 === 1) return piece; // code block
    const hadMarkup = /<\/?(box|row|AsyncImage|Cite|Entity|WritingBlock|MemoryCite|radio-group)\b/.test(piece) || /\{@body/.test(piece);
    let p = hadMarkup ? cleanGenUiSegment(piece) : piece;
    p = decodeHtmlEntities(p);
    if (hadMarkup) {
      // Indentation here came from nested layout boxes, not from the content — flatten it.
      p = p.split("\n").map(l => l.replace(/^[ \t]+/, "").replace(/[ \t]+$/, "")).join("\n");
      // Tighten option lists that came from radio buttons (one blank line between each).
      p = p.replace(/\n{2,}(?=- )/g, (m, off) => (/\n- [^\n]*$/.test(p.slice(0, off)) ? "\n" : m));
    }
    return p;
  }).join("");
  return cleaned.replace(/\n{3,}/g, "\n\n").trim();
}

function conversationJsonToMessages(json) {
  const mapping = json.mapping || {};
  let nodeId = json.current_node;
  const chain = [];
  const seen = new Set();
  while (nodeId && mapping[nodeId] && !seen.has(nodeId)) {
    seen.add(nodeId);
    chain.push(nodeId);
    nodeId = mapping[nodeId].parent;
  }
  chain.reverse();

  const messages = [];
  chain.forEach(id => {
    const node = mapping[id];
    const msg = node && node.message;
    if (!msg || !msg.author) return;
    const role = msg.author.role;
    if (role !== "user" && role !== "assistant") return;
    const meta = msg.metadata || {};
    if (meta.is_visually_hidden_from_conversation) return;
    const content = msg.content || {};
    const recipient = msg.recipient || "all";

    // Canvas / document blocks: ChatGPT writes these as a tool call whose text is JSON
    // holding the document body. Include the document so the transcript isn't missing it.
    if (role === "assistant" && /^canmore\./.test(recipient) && typeof content.text === "string") {
      try {
        const doc = JSON.parse(content.text);
        const body = doc.content || (Array.isArray(doc.updates) ? doc.updates.map(u => u.replacement).filter(Boolean).join("\n") : "");
        if (body) messages.push({ role, time: msg.create_time || null, attachments: [], text: `\uE000${doc.name || ""}\uE001\n${cleanMessageText(body)}\n\uE002` });
      } catch (e) { /* not JSON — skip */ }
      return;
    }

    // Skip other tool calls (search queries, code-interpreter input, etc.) and reasoning.
    if (recipient !== "all") return;
    if (["thoughts", "reasoning_recap", "user_editable_context", "model_editable_context"].includes(content.content_type)) return;

    const parts = content.parts || [];
    const text = cleanMessageText(parts.filter(p => typeof p === "string").join("\n").trim());

    // Attached files (names only — file contents aren't part of the conversation data).
    const attachments = (Array.isArray(meta.attachments) ? meta.attachments : [])
      .map(a => a && a.name).filter(Boolean);
    const imageCount = parts.filter(p => p && typeof p === "object" && /image/.test(p.content_type || "")).length;
    if (imageCount > attachments.length) {
      for (let k = attachments.length; k < imageCount; k++) attachments.push("(image)");
    }

    if (!text && !attachments.length) return;
    messages.push({ role, time: msg.create_time || null, attachments, text });
  });
  return messages;
}

// Runs inside the open chatgpt.com tab (MAIN world, so requests carry your normal session
// exactly as the page's own requests do). Gets the page's access token from the same
// session endpoint the page uses, then loads this one conversation.
async function fetchConversationViaPage(tabId, chatId) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      args: [chatId],
      func: async (id) => {
        try {
          const cookie = (name) => {
            const m = document.cookie.match(new RegExp("(?:^|; )" + name + "=([^;]*)"));
            return m ? decodeURIComponent(m[1]) : null;
          };
          const sessionRes = await fetch("/api/auth/session", { credentials: "include" });
          if (!sessionRes.ok) return { ok: false, error: `session ${sessionRes.status}` };
          const session = await sessionRes.json();
          const token = session && session.accessToken;
          if (!token) return { ok: false, error: "not signed in" };

          const headers = { Authorization: `Bearer ${token}` };
          const deviceId = cookie("oai-did");
          if (deviceId) headers["oai-device-id"] = deviceId;
          const accountId = cookie("_account");
          if (accountId && accountId !== "personal") headers["chatgpt-account-id"] = accountId;

          const res = await fetch(`/backend-api/conversation/${encodeURIComponent(id)}`, { credentials: "include", headers });
          if (!res.ok) return { ok: false, error: `conversation ${res.status}` };
          const json = await res.json();
          if (!json || !json.mapping) return { ok: false, error: "unexpected response shape" };
          return { ok: true, data: { mapping: json.mapping, current_node: json.current_node, title: json.title } };
        } catch (e) {
          return { ok: false, error: String((e && e.message) || e) };
        }
      }
    });
    return results && results[0] ? results[0].result : { ok: false, error: "No result from page" };
  } catch (e) {
    return { ok: false, error: String((e && e.message) || e) };
  }
}

function isShareUrl(url) {
  return !!url && /\/share\//.test(url);
}

// Reads the rendered messages off an open ChatGPT chat or share page (fallback path). On share
// pages this is the only path; on private chats it is used only if the JSON read fails. Selectors confirmed
// from real inspected markup: each message sits in a div carrying
// data-message-author-role="user"/"assistant", which precisely wraps just that message's
// content and excludes surrounding page chrome (Sources button, footnotes, etc.).
//
// Uses textContent rather than innerText: very long messages get optimized with CSS
// content-visibility, which makes browsers report empty/truncated text via innerText for
// whatever portion isn't currently laid out on screen, even though it's present in the DOM.
// textContent reads the DOM directly regardless of rendering state, avoiding that truncation.
async function extractPageMessages(tabId) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: async () => {
        try {
          const getFullText = (el) => {
            const clone = el.cloneNode(true);
            clone.querySelectorAll("script, style").forEach(n => n.remove());
            return (clone.textContent || "").trim();
          };

          const countCandidates = () => document.querySelectorAll("[data-message-author-role]").length;

          // Long conversations likely only keep recent messages mounted, loading older
          // ones as you scroll toward the top. Force everything to load first by
          // scrolling to top repeatedly until the message count stops growing.
          const findScrollables = () =>
            Array.from(document.querySelectorAll("*")).filter(el => el.scrollHeight - el.clientHeight > 50);

          let scrollables = findScrollables();
          let lastCount = -1;
          let stableRounds = 0;
          for (let i = 0; i < 50 && stableRounds < 3; i++) {
            window.scrollTo(0, 0);
            scrollables.forEach(el => { el.scrollTop = 0; });
            await new Promise(r => setTimeout(r, 350));
            const count = countCandidates();
            if (count === lastCount) {
              stableRounds++;
            } else {
              stableRounds = 0;
              scrollables = findScrollables();
            }
            lastCount = count;
          }

          const dedupeTopLevel = nodes => nodes.filter(node => !nodes.some(other => other !== node && other.contains(node)));

          const primary = dedupeTopLevel(Array.from(document.querySelectorAll("[data-message-author-role]")));
          if (primary.length) {
            const messages = primary
              .map(el => ({ role: el.getAttribute("data-message-author-role"), text: getFullText(el) }))
              .filter(m => (m.role === "user" || m.role === "assistant") && m.text);
            if (messages.length) return { ok: true, messages, count: messages.length, method: "role-attribute" };
          }

          // Fallback only if the role attribute genuinely isn't present on this page.
          const rawNodes = dedupeTopLevel(Array.from(document.querySelectorAll(".whitespace-pre-wrap, .markdown.prose")));
          const messages = rawNodes
            .map(el => ({ role: el.classList.contains("whitespace-pre-wrap") ? "user" : "assistant", text: getFullText(el) }))
            .filter(m => m.text);
          if (messages.length) return { ok: true, messages, count: messages.length, method: "class-fallback" };

          return { ok: false, error: "No message content found with any known selector." };
        } catch (e) {
          return { ok: false, error: String((e && e.message) || e) };
        }
      }
    });
    return results && results[0] ? results[0].result : { ok: false, error: "No result from page" };
  } catch (e) {
    return { ok: false, error: String((e && e.message) || e) };
  }
}

function safeFileName(name) {
  return (name || "chat").replace(/[\\/:*?"<>|]+/g, "_").trim().slice(0, 60) || "chat";
}

function downloadTextFile(filename, text, mimeType) {
  const blob = new Blob([text], { type: mimeType || "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// Browser tab titles for ChatGPT reliably follow "<conversation title> - ChatGPT" (or similar).
// This relies only on the standard tabs API, not on scraping ChatGPT's page DOM, so it doesn't
// break when they change their frontend markup.
//
// Chats inside a ChatGPT Project show as "<Project name> - <conversation title> - ChatGPT".
// We can't safely guess which leading segment is a project name (some of your own chat titles
// may legitimately contain a dash), so projectPrefixes is an explicit, user-maintained list of
// exact project names to strip — deterministic, no risk of mangling an unrelated title.
function cleanTabTitle(rawTitle, projectPrefixes) {
  if (!rawTitle) return "Untitled";
  let cleaned = rawTitle.replace(/\s*[-|]\s*ChatGPT\s*$/i, "").trim();

  if (Array.isArray(projectPrefixes)) {
    for (const raw of projectPrefixes) {
      const p = (raw || "").trim();
      if (!p) continue;
      for (const sep of [" - ", " \u2013 ", ": "]) {
        const prefix = p + sep;
        if (cleaned.startsWith(prefix)) {
          cleaned = cleaned.slice(prefix.length).trim();
          break;
        }
      }
    }
  }

  return cleaned || "Untitled";
}
