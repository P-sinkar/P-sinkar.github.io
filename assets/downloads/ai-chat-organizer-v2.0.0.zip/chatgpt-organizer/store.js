// Shared storage + site registry for Pranav's AI Chat Organizer (ChatGPT + Claude).
//
// Data shape (unchanged from the ChatGPT organizer, so existing data loads as-is):
// {
//   folders: { [folderId]: { id, name, parentId, order?, collapsed? } },  // parentId null = top level
//   chats:   { [chatId]:   { id, title, folderId, createTime, titleLocked?, platform? } }
// }
// `platform` is "chatgpt" or "claude". Records saved before the merge have no platform field
// and are ChatGPT chats — chatPlatform() treats a missing value as "chatgpt".
// Chat ids from both sites are UUIDs, so they can share one map without colliding.

// Storage keys keep their original ChatGPT-organizer names on purpose: installing this over
// the ChatGPT organizer's folder means your existing folders and chats are simply there.
const STORE_KEY = "cgpt_organizer_data_v1";
const LAST_BACKUP_KEY = "cgpt_organizer_last_backup";
const SORT_PREFS_KEY = "cgpt_organizer_sort_prefs";
const BACKUP_DISMISS_KEY = "cgpt_organizer_backup_dismiss_until";
const PLATFORM_FILTER_KEY = "aiorg_platform_filter";

// ---------- Sites ----------

const PLATFORMS = {
  chatgpt: {
    id: "chatgpt",
    label: "ChatGPT",
    badge: "GPT",
    hosts: ["chatgpt.com", "chat.openai.com"],
    chatUrl: id => `https://chatgpt.com/c/${id}`,
    idPattern: /\/c\/([a-zA-Z0-9-]+)/,
    sharePattern: /\/share\//,
    titleSuffix: /\s*[-|]\s*ChatGPT\s*$/i,
    prefixesKey: "cgpt_organizer_project_prefixes",
    exportHelp: "ChatGPT: Settings → Data controls → Export data"
  },
  claude: {
    id: "claude",
    label: "Claude",
    badge: "Claude",
    hosts: ["claude.ai"],
    chatUrl: id => `https://claude.ai/chat/${id}`,
    idPattern: /\/chat\/([a-zA-Z0-9-]+)/,
    sharePattern: /\/share\//,
    titleSuffix: /\s*[-|]\s*Claude\s*$/i,
    prefixesKey: "aiorg_project_prefixes_claude",
    exportHelp: "Claude: Settings → Privacy → Export data"
  }
};

function platformOfUrl(url) {
  if (!url) return null;
  let host;
  try { host = new URL(url).hostname; } catch (e) { return null; }
  for (const p of Object.values(PLATFORMS)) {
    if (p.hosts.some(h => host === h || host.endsWith("." + h))) return p.id;
  }
  return null;
}

function chatPlatform(chat) {
  return (chat && PLATFORMS[chat.platform]) ? chat.platform : "chatgpt";
}

function chatUrlFor(chat) {
  return PLATFORMS[chatPlatform(chat)].chatUrl(chat.id);
}

function extractConversationId(url) {
  const p = platformOfUrl(url);
  if (!p) return null;
  const m = url.match(PLATFORMS[p].idPattern);
  return m ? m[1] : null;
}

function isShareUrl(url) {
  const p = platformOfUrl(url);
  return !!p && PLATFORMS[p].sharePattern.test(new URL(url).pathname);
}

// ---------- Storage ----------

function emptyData() {
  return { folders: {}, chats: {} };
}

async function loadData() {
  const res = await chrome.storage.local.get(STORE_KEY);
  const data = res[STORE_KEY];
  if (!data) return emptyData();
  if (!data.folders) data.folders = {};
  if (!data.chats) data.chats = {};
  return data;
}

async function saveData(data) {
  await chrome.storage.local.set({ [STORE_KEY]: data });
}

function newId(prefix) {
  return prefix + "_" + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

async function getLastBackupTime() {
  const res = await chrome.storage.local.get(LAST_BACKUP_KEY);
  return res[LAST_BACKUP_KEY] || null;
}

async function setLastBackupTime(ts) {
  await chrome.storage.local.set({ [LAST_BACKUP_KEY]: ts });
}

// Project-name lists are kept per site (a ChatGPT project and a Claude project can share a name
// without either list affecting the other site's titles).
async function getProjectPrefixes(platform) {
  const key = PLATFORMS[platform || "chatgpt"].prefixesKey;
  const res = await chrome.storage.local.get(key);
  return Array.isArray(res[key]) ? res[key] : [];
}

async function setProjectPrefixes(platform, list) {
  await chrome.storage.local.set({ [PLATFORMS[platform || "chatgpt"].prefixesKey]: list });
}

const DEFAULT_SORT_PREFS = { chatSort: "date_desc", folderSort: "name_asc" };

async function getSortPrefs() {
  const res = await chrome.storage.local.get(SORT_PREFS_KEY);
  return Object.assign({}, DEFAULT_SORT_PREFS, res[SORT_PREFS_KEY] || {});
}

async function setSortPrefs(prefs) {
  await chrome.storage.local.set({ [SORT_PREFS_KEY]: prefs });
}

async function getPlatformFilter() {
  const res = await chrome.storage.local.get(PLATFORM_FILTER_KEY);
  return res[PLATFORM_FILTER_KEY] || "all";
}

async function setPlatformFilter(v) {
  await chrome.storage.local.set({ [PLATFORM_FILTER_KEY]: v });
}

async function getBackupDismissUntil() {
  const res = await chrome.storage.local.get(BACKUP_DISMISS_KEY);
  return res[BACKUP_DISMISS_KEY] || 0;
}

async function setBackupDismissUntil(ts) {
  await chrome.storage.local.set({ [BACKUP_DISMISS_KEY]: ts });
}

// ---------- Titles ----------

// Tab titles look like "<chat title> - ChatGPT" / "<chat title> - Claude". Chats inside a
// Project may get "<Project name> - " in front; projectPrefixes is your explicit list of
// exact project names to strip (no guessing, so a title that legitimately contains a dash
// is never mangled). Uses only the standard tabs API, not the site's page markup.
function cleanTabTitle(rawTitle, projectPrefixes, platform) {
  if (!rawTitle) return "Untitled";
  const p = PLATFORMS[platform || "chatgpt"];
  let cleaned = rawTitle.replace(p.titleSuffix, "").trim();

  if (Array.isArray(projectPrefixes)) {
    for (const raw of projectPrefixes) {
      const pre = (raw || "").trim();
      if (!pre) continue;
      for (const sep of [" - ", " – ", ": "]) {
        const prefix = pre + sep;
        if (cleaned.startsWith(prefix)) {
          cleaned = cleaned.slice(prefix.length).trim();
          break;
        }
      }
    }
  }

  return cleaned || "Untitled";
}

// ---------- Downloads ----------

function safeFileName(name) {
  return (name || "chat").replace(/[\\/:*?"<>|]+/g, "_").trim().slice(0, 60) || "chat";
}

function downloadTextFile(filename, text, mimeType) {
  const blob = new Blob([text], { type: mimeType || "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
