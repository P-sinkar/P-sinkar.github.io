let DATA = emptyData();
let SELECTED = { type: "all" }; // {type:'all'} | {type:'unorganized'} | {type:'folder', id}
let unorganizedCollapsed = false;
let CHAT_SORT = "date_desc";
let FOLDER_SORT = "name_asc";
let PLATFORM_FILTER = "all"; // "all" | "chatgpt" | "claude" — which site's chats are shown
let ACTIVE_PLATFORM = null;  // site of the active tab (null when it isn't ChatGPT or Claude)

function isVisible(c) {
  return PLATFORM_FILTER === "all" || chatPlatform(c) === PLATFORM_FILTER;
}

function platformBadge(c) {
  const p = PLATFORMS[chatPlatform(c)];
  return `<span class="pf-badge pf-${p.id}" title="${p.label} chat">${p.badge}</span>`;
}

function sortChats(chats) {
  const arr = chats.slice();
  switch (CHAT_SORT) {
    case "date_asc": arr.sort((a, b) => (a.createTime || 0) - (b.createTime || 0)); break;
    case "title_asc": arr.sort((a, b) => (a.title || "").localeCompare(b.title || "")); break;
    case "title_desc": arr.sort((a, b) => (b.title || "").localeCompare(a.title || "")); break;
    default: arr.sort((a, b) => (b.createTime || 0) - (a.createTime || 0)); // date_desc
  }
  return arr;
}

function chatsInFolder(folderId) {
  return Object.values(DATA.chats).filter(c => c.folderId === folderId && isVisible(c));
}

function allChats() {
  return Object.values(DATA.chats).filter(isVisible);
}

function childFolders(parentId) {
  const arr = Object.values(DATA.folders).filter(f => f.parentId === parentId);
  if (FOLDER_SORT === "custom") {
    arr.sort((a, b) => (a.order || 0) - (b.order || 0));
  } else {
    arr.sort((a, b) => FOLDER_SORT === "name_desc" ? b.name.localeCompare(a.name) : a.name.localeCompare(b.name));
  }
  return arr;
}

function reorderFolder(draggedId, newParentId, targetId, zone) {
  DATA.folders[draggedId].parentId = newParentId;
  const siblings = Object.values(DATA.folders)
    .filter(f => f.parentId === newParentId && f.id !== draggedId)
    .sort((a, b) => (a.order || 0) - (b.order || 0));
  const targetIndex = siblings.findIndex(f => f.id === targetId);
  const insertAt = zone === "before" ? targetIndex : targetIndex + 1;
  siblings.splice(insertAt, 0, DATA.folders[draggedId]);
  siblings.forEach((f, i) => { f.order = i; });
}

function startFolderRename(nameEl, folder) {
  const input = document.createElement("input");
  input.type = "text";
  input.className = "inline-edit-input";
  input.value = folder.name || "";
  nameEl.replaceWith(input);
  input.focus();
  input.select();

  let settled = false;
  const commit = async () => {
    if (settled) return;
    settled = true;
    const val = input.value.trim();
    if (val) {
      folder.name = val;
      await persist();
    }
    renderAll();
  };
  const cancel = () => {
    if (settled) return;
    settled = true;
    renderAll();
  };

  input.addEventListener("keydown", (ev) => {
    if (ev.key === "Enter") { ev.preventDefault(); commit(); }
    else if (ev.key === "Escape") { ev.preventDefault(); cancel(); }
  });
  input.addEventListener("blur", commit);
}

function countInSubtree(folderId) {
  let count = chatsInFolder(folderId).length;
  childFolders(folderId).forEach(f => { count += countInSubtree(f.id); });
  return count;
}

function fmtDate(ts) {
  if (!ts) return "";
  const d = new Date(ts * 1000 > Date.now() * 2 ? ts : ts * 1000); // handle sec vs ms defensively
  if (isNaN(d.getTime())) return "";
  return d.toLocaleDateString();
}

async function persist() {
  await saveData(DATA);
}

// ---------- Tree rendering ----------

function renderTree() {
  const tree = document.getElementById("tree");
  tree.innerHTML = "";

  const sortRow = document.createElement("div");
  sortRow.className = "tree-sort-row";
  sortRow.innerHTML = `
    <select id="folderSortSelect">
      <option value="name_asc">Folders: A&ndash;Z</option>
      <option value="name_desc">Folders: Z&ndash;A</option>
      <option value="custom">Folders: Custom order</option>
    </select>
  `;
  tree.appendChild(sortRow);
  const folderSortSelect = sortRow.querySelector("select");
  folderSortSelect.value = FOLDER_SORT;
  folderSortSelect.addEventListener("change", async (e) => {
    FOLDER_SORT = e.target.value;
    await setSortPrefs({ chatSort: CHAT_SORT, folderSort: FOLDER_SORT });
    renderTree();
  });

  tree.appendChild(makeStaticRow("All chats", { type: "all" }, allChats().length, true));
  tree.appendChild(renderUnorganizedNode());

  const rootWrap = document.createElement("div");
  rootWrap.style.marginTop = "10px";
  childFolders(null).forEach(f => rootWrap.appendChild(renderFolderNode(f)));
  tree.appendChild(rootWrap);
}

function makeStaticRow(label, sel, count, acceptsFolderDrop) {
  const row = document.createElement("div");
  row.className = "folder-row" + (isSelected(sel) ? " active" : "");
  row.innerHTML = `<span>${label}</span><span class="count">${count}</span>`;
  row.addEventListener("click", () => { SELECTED = sel; renderAll(); });

  if (acceptsFolderDrop) {
    row.title = "Drop a folder here to move it to the top level";
    row.addEventListener("dragover", e => { e.preventDefault(); row.classList.add("drop-target"); });
    row.addEventListener("dragleave", () => row.classList.remove("drop-target"));
    row.addEventListener("drop", async e => {
      e.preventDefault();
      row.classList.remove("drop-target");
      const draggedFolderId = e.dataTransfer.getData("text/folder-id");
      if (draggedFolderId && DATA.folders[draggedFolderId]) {
        DATA.folders[draggedFolderId].parentId = null;
        await persist();
        renderAll();
      }
    });
  }

  return row;
}

function renderUnorganizedNode() {
  const node = document.createElement("div");
  const row = document.createElement("div");
  row.className = "folder-row" + (isSelected({ type: "unorganized" }) ? " active" : "");

  const chats = chatsInFolder(null);
  const hasChildren = chats.length > 0;
  const caret = hasChildren ? (unorganizedCollapsed ? "\u25B8" : "\u25BE") : "";

  row.innerHTML = `<span class="caret">${caret}</span><span>Unorganized</span><span class="count">${chats.length}</span>`;

  row.addEventListener("click", (e) => {
    if (e.target.classList.contains("caret") && hasChildren) {
      unorganizedCollapsed = !unorganizedCollapsed;
      renderTree();
      return;
    }
    SELECTED = { type: "unorganized" };
    renderAll();
  });

  row.addEventListener("dragover", e => { e.preventDefault(); row.classList.add("drop-target"); });
  row.addEventListener("dragleave", () => row.classList.remove("drop-target"));
  row.addEventListener("drop", async e => {
    e.preventDefault();
    row.classList.remove("drop-target");
    const chatId = e.dataTransfer.getData("text/chat-id");
    if (chatId && DATA.chats[chatId]) {
      DATA.chats[chatId].folderId = null;
      await persist();
      renderAll();
    }
  });

  node.appendChild(row);

  if (hasChildren && !unorganizedCollapsed) {
    const childWrap = document.createElement("div");
    childWrap.className = "folder-children";
    sortChats(chats).forEach(c => childWrap.appendChild(renderChatLeaf(c)));
    node.appendChild(childWrap);
  }

  return node;
}

function isSelected(sel) {
  if (sel.type !== SELECTED.type) return false;
  if (sel.type === "folder") return sel.id === SELECTED.id;
  return true;
}

function renderFolderNode(folder) {
  const node = document.createElement("div");
  node.className = "folder-node";

  const row = document.createElement("div");
  row.className = "folder-row" + (isSelected({ type: "folder", id: folder.id }) ? " active" : "");

  const kids = childFolders(folder.id);
  const folderChats = chatsInFolder(folder.id);
  const hasChildren = kids.length > 0 || folderChats.length > 0;
  const caret = hasChildren ? (folder.collapsed ? "\u25B8" : "\u25BE") : "";

  row.innerHTML = `
    <span class="caret">${caret}</span>
    <span class="name">${escapeHtml(folder.name)}</span>
    <span class="folder-actions">
      <span data-action="rename" title="Rename">\u270E</span>
      <span data-action="delete" title="Delete">\uD83D\uDDD1</span>
      <span data-action="add" title="Add subfolder">+</span>
    </span>
    <span class="count">${countInSubtree(folder.id)}</span>
  `;

  row.addEventListener("click", (e) => {
    if (e.target.dataset.action) return;
    if (e.target.classList.contains("caret") && hasChildren) {
      folder.collapsed = !folder.collapsed;
      persist();
      renderTree();
      return;
    }
    SELECTED = { type: "folder", id: folder.id };
    renderAll();
  });

  row.addEventListener("dragover", e => {
    e.preventDefault();
    const isFolderDrag = e.dataTransfer.types.includes("text/folder-id");
    row.classList.remove("drop-into", "drop-before", "drop-after");
    if (isFolderDrag) {
      const rect = row.getBoundingClientRect();
      const ratio = (e.clientY - rect.top) / rect.height;
      if (ratio < 0.25) { row.classList.add("drop-before"); row.dataset.dropZone = "before"; }
      else if (ratio > 0.75) { row.classList.add("drop-after"); row.dataset.dropZone = "after"; }
      else { row.classList.add("drop-into"); row.dataset.dropZone = "into"; }
    } else {
      row.classList.add("drop-into");
      row.dataset.dropZone = "into";
    }
  });
  row.addEventListener("dragleave", () => {
    row.classList.remove("drop-into", "drop-before", "drop-after");
    delete row.dataset.dropZone;
  });
  row.addEventListener("drop", async e => {
    e.preventDefault();
    const zone = row.dataset.dropZone || "into";
    row.classList.remove("drop-into", "drop-before", "drop-after");
    delete row.dataset.dropZone;

    const chatId = e.dataTransfer.getData("text/chat-id");
    const draggedFolderId = e.dataTransfer.getData("text/folder-id");

    if (chatId && DATA.chats[chatId]) {
      DATA.chats[chatId].folderId = folder.id;
      await persist();
      renderAll();
      return;
    }

    if (draggedFolderId && DATA.folders[draggedFolderId] && draggedFolderId !== folder.id) {
      const newParentId = zone === "into" ? folder.id : folder.parentId;
      if (newParentId && isWithinSubtree(newParentId, draggedFolderId)) {
        alert("Can't move a folder into itself or one of its own subfolders.");
        return;
      }
      if (zone === "into") {
        DATA.folders[draggedFolderId].parentId = newParentId;
        DATA.folders[draggedFolderId].order = Date.now();
      } else {
        reorderFolder(draggedFolderId, newParentId, folder.id, zone);
      }
      if (FOLDER_SORT !== "custom") {
        FOLDER_SORT = "custom";
        await setSortPrefs({ chatSort: CHAT_SORT, folderSort: FOLDER_SORT });
      }
      await persist();
      renderAll();
    }
  });

  row.draggable = true;
  row.addEventListener("dragstart", e => {
    e.dataTransfer.setData("text/folder-id", folder.id);
  });

  row.querySelector('[data-action="add"]').addEventListener("click", async (e) => {
    e.stopPropagation();
    const name = prompt("New subfolder name:");
    if (!name) return;
    const fid = newId("f");
    DATA.folders[fid] = { id: fid, name, parentId: folder.id, order: Date.now() };
    await persist();
    renderTree();
  });

  row.querySelector('[data-action="rename"]').addEventListener("click", (e) => {
    e.stopPropagation();
    startFolderRename(row.querySelector(".name"), folder);
  });

  row.querySelector('[data-action="delete"]').addEventListener("click", async (e) => {
    e.stopPropagation();
    if (!confirm(`Delete "${folder.name}" and its subfolders? Chats inside will move to Unorganized.`)) return;
    deleteFolderRecursive(folder.id);
    if (SELECTED.type === "folder" && SELECTED.id === folder.id) SELECTED = { type: "all" };
    await persist();
    renderAll();
  });

  node.appendChild(row);

  if (hasChildren && !folder.collapsed) {
    const childWrap = document.createElement("div");
    childWrap.className = "folder-children";
    kids.forEach(f => childWrap.appendChild(renderFolderNode(f)));
    sortChats(folderChats).forEach(c => childWrap.appendChild(renderChatLeaf(c)));
    node.appendChild(childWrap);
  }

  return node;
}

function renderChatLeaf(chat) {
  const row = document.createElement("div");
  row.className = "tree-chat-leaf";
  row.draggable = true;
  row.innerHTML = `
    ${platformBadge(chat)}<span class="leaf-title">${chat.titleLocked ? "\uD83D\uDD12 " : ""}${escapeHtml(chat.title || "Untitled")}</span>
    <span class="leaf-actions">
      ${chat.folderId ? '<span data-action="unassign" title="Move to Unorganized">\u00D7</span>' : ""}
      <span data-action="edit" title="Edit title">\u270E</span>
      <span data-action="remove" title="Remove from organizer (does not delete the chat itself)">\uD83D\uDDD1</span>
    </span>
  `;

  row.querySelector(".leaf-title").addEventListener("click", async (e) => {
    const url = chatUrlFor(chat);
    if (e.ctrlKey || e.metaKey) {
      chrome.tabs.create({ url });
      return;
    }
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (activeTab) chrome.tabs.update(activeTab.id, { url });
    else chrome.tabs.create({ url });
  });

  const unassignBtn = row.querySelector('[data-action="unassign"]');
  if (unassignBtn) {
    unassignBtn.addEventListener("click", async (e) => {
      e.stopPropagation();
      chat.folderId = null;
      await persist();
      renderAll();
    });
  }

  row.querySelector('[data-action="edit"]').addEventListener("click", (e) => {
    e.stopPropagation();
    startInlineEdit(row.querySelector(".leaf-title"), chat, renderAll);
  });

  row.querySelector('[data-action="remove"]').addEventListener("click", async (e) => {
    e.stopPropagation();
    if (!confirm(`Remove "${chat.title || "Untitled"}" from the organizer? This only stops tracking it here — it won't touch the actual chat on ${PLATFORMS[chatPlatform(chat)].label}.`)) return;
    delete DATA.chats[chat.id];
    await persist();
    renderAll();
  });

  row.addEventListener("dragstart", e => {
    e.dataTransfer.setData("text/chat-id", chat.id);
  });

  return row;
}

function isWithinSubtree(candidateId, rootId) {
  // true if candidateId is rootId itself, or a descendant of rootId
  let current = candidateId;
  while (current) {
    if (current === rootId) return true;
    current = DATA.folders[current] ? DATA.folders[current].parentId : null;
  }
  return false;
}

function deleteFolderRecursive(folderId) {
  childFolders(folderId).forEach(f => deleteFolderRecursive(f.id));
  Object.values(DATA.chats).forEach(c => { if (c.folderId === folderId) c.folderId = null; });
  delete DATA.folders[folderId];
}

// Swaps a title span for an inline text input (avoids window.prompt(), which is
// unreliable inside extension popups/side panels). Enter saves, Escape cancels, blur saves.
function startInlineEdit(titleEl, chatRecord, onDone) {
  const input = document.createElement("input");
  input.type = "text";
  input.className = "inline-edit-input";
  input.value = chatRecord.title || "";
  titleEl.replaceWith(input);
  input.focus();
  input.select();

  let settled = false;
  const commit = async () => {
    if (settled) return;
    settled = true;
    const val = input.value.trim();
    if (val) {
      chatRecord.title = val;
      chatRecord.titleLocked = true;
      await persist();
    }
    onDone();
  };
  const cancel = () => {
    if (settled) return;
    settled = true;
    onDone();
  };

  input.addEventListener("keydown", (ev) => {
    if (ev.key === "Enter") { ev.preventDefault(); commit(); }
    else if (ev.key === "Escape") { ev.preventDefault(); cancel(); }
  });
  input.addEventListener("blur", commit);
}

// ---------- Chat list rendering ----------

function renderChatList() {
  const container = document.getElementById("chatList");
  container.innerHTML = "";

  const query = document.getElementById("searchBox").value.trim().toLowerCase();

  let chats;
  if (query) {
    chats = allChats().filter(c => (c.title || "").toLowerCase().includes(query));
  } else if (SELECTED.type === "all") {
    chats = allChats();
  } else if (SELECTED.type === "unorganized") {
    chats = chatsInFolder(null);
  } else {
    chats = chatsInFolder(SELECTED.id);
  }

  chats = sortChats(chats);

  if (!chats.length) {
    container.innerHTML = '<div class="empty-state">No chats here yet. Drag chats onto a folder, or import a ChatGPT or Claude export.</div>';
    return;
  }

  chats.forEach(c => {
    const item = document.createElement("div");
    item.className = "chat-item";
    item.draggable = true;
    item.innerHTML = `
      <span class="title">${platformBadge(c)} ${c.titleLocked ? '<span class="lock-badge" title="Title locked \u2014 won\'t auto-update from the browser tab">\uD83D\uDD12</span> ' : ""}${escapeHtml(c.title || "Untitled")}</span>
      <span>
        <span class="date">${fmtDate(c.createTime)}</span>
        ${c.folderId ? '<span class="unassign" title="Move to Unorganized">move to Unorganized</span>' : ""}
        <span class="edit-link" title="Edit title">edit title</span>
        ${c.titleLocked ? '<span class="unlock-link" title="Allow auto-sync from the browser tab again">unlock</span>' : ""}
        <span class="remove-link" title="Remove from organizer (does not delete the chat itself)">remove</span>
      </span>
    `;
    item.querySelector(".title").addEventListener("click", async (e) => {
      const url = chatUrlFor(c);
      if (e.ctrlKey || e.metaKey) {
        // Ctrl/Cmd+click still opens a new tab, matching normal browser link behavior
        chrome.tabs.create({ url });
        return;
      }
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (activeTab) {
        chrome.tabs.update(activeTab.id, { url });
      } else {
        chrome.tabs.create({ url });
      }
    });
    const unassign = item.querySelector(".unassign");
    if (unassign) {
      unassign.addEventListener("click", async (e) => {
        e.stopPropagation();
        c.folderId = null;
        await persist();
        renderAll();
      });
    }
    item.querySelector(".edit-link").addEventListener("click", (e) => {
      e.stopPropagation();
      startInlineEdit(item.querySelector(".title"), c, renderAll);
    });
    const unlockLink = item.querySelector(".unlock-link");
    if (unlockLink) {
      unlockLink.addEventListener("click", async (e) => {
        e.stopPropagation();
        c.titleLocked = false;
        await persist();
        renderAll();
      });
    }
    item.querySelector(".remove-link").addEventListener("click", async (e) => {
      e.stopPropagation();
      if (!confirm(`Remove "${c.title || "Untitled"}" from the organizer? This only stops tracking it here — it won't touch the actual chat on ${PLATFORMS[chatPlatform(c)].label}.`)) return;
      delete DATA.chats[c.id];
      await persist();
      renderAll();
    });
    item.addEventListener("dragstart", e => {
      e.dataTransfer.setData("text/chat-id", c.id);
    });
    container.appendChild(item);
  });
}

function renderAll() {
  renderTree();
  renderChatList();
}

// ---------- Import from an official export (ChatGPT or Claude — detected per file) ----------
// ChatGPT's conversations.json entries carry `mapping` / `conversation_id` / numeric create_time;
// Claude's carry `uuid` / `name` / `chat_messages` / ISO created_at. Only id, title and date are
// used; folder assignments are never touched. Re-importing refreshes titles and locks them.

function detectExportPlatform(conv) {
  if (!conv || typeof conv !== "object") return null;
  if (conv.mapping || conv.conversation_id || typeof conv.create_time === "number") return "chatgpt";
  if (conv.chat_messages || conv.uuid) return "claude";
  return null;
}

function exportEntryFields(conv, platform) {
  if (platform === "claude") {
    const t = Date.parse(conv.created_at || conv.updated_at || "");
    return { id: conv.uuid || conv.id, title: (conv.name || conv.title || "").trim() || "Untitled", createTime: Number.isFinite(t) ? t / 1000 : 0 };
  }
  return { id: conv.conversation_id || conv.id, title: conv.title || "Untitled", createTime: conv.create_time || conv.update_time || 0 };
}

function exportList(parsed) {
  return Array.isArray(parsed) ? parsed : ((parsed && parsed.conversations) || []);
}

document.getElementById("importBtn").addEventListener("click", () => {
  document.getElementById("importFile").click();
});

document.getElementById("importFile").addEventListener("change", async (e) => {
  const file = e.target.files[0];
  e.target.value = "";
  if (!file) return;
  let parsed;
  try {
    parsed = JSON.parse(await file.text());
  } catch (err) {
    showImportStatus("Could not parse that file as JSON. Use conversations.json from your ChatGPT or Claude data export.", true);
    return;
  }

  let added = 0, titlesUpdated = 0, unchanged = 0, skipped = 0;
  const perSite = { chatgpt: 0, claude: 0 };

  exportList(parsed).forEach(conv => {
    const platform = detectExportPlatform(conv);
    if (!platform) { skipped++; return; }
    const { id, title, createTime } = exportEntryFields(conv, platform);
    if (!id) { skipped++; return; }
    perSite[platform]++;
    const existing = DATA.chats[id];
    if (existing) {
      if (existing.title !== title) { existing.title = title; titlesUpdated++; } else { unchanged++; }
      existing.titleLocked = true; // the export's title is authoritative — protect it from tab-title sync
      existing.platform = platform;
      if (!existing.createTime && createTime) existing.createTime = createTime;
      return; // never touches folderId
    }
    DATA.chats[id] = { id, title, folderId: null, createTime, titleLocked: true, platform };
    added++;
  });

  if (!perSite.chatgpt && !perSite.claude) {
    showImportStatus("No conversations found in that file. Use conversations.json from your ChatGPT or Claude data export (not this extension's own backup — that goes in Restore backup).", true);
    return;
  }
  await persist();
  const sites = [perSite.chatgpt ? `${perSite.chatgpt} ChatGPT` : "", perSite.claude ? `${perSite.claude} Claude` : ""].filter(Boolean).join(" + ");
  showImportStatus(`Read ${sites} conversation${perSite.chatgpt + perSite.claude === 1 ? "" : "s"}: ${added} new, ${titlesUpdated} title${titlesUpdated === 1 ? "" : "s"} refreshed, ${unchanged} unchanged.`);
  SELECTED = { type: "unorganized" };
  renderAll();
});

function showImportStatus(msg, isError) {
  const el = document.getElementById("importStatus");
  el.textContent = msg;
  el.style.display = "block";
  el.style.background = isError ? "#fdeaea" : "#eaf7ea";
  el.style.color = isError ? "#8a1a1a" : "#1a5c1a";
}

// ---------- Backup / restore ----------

document.getElementById("exportBtn").addEventListener("click", async () => {
  // Stamp every chat with its site so the backup is self-describing.
  Object.values(DATA.chats).forEach(c => { c.platform = chatPlatform(c); });
  const payload = Object.assign({ app: "ai-chat-organizer", version: 2 }, DATA);
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `ai-chat-organizer-backup-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
  await setLastBackupTime(Date.now());
  document.getElementById("backupReminder").style.display = "none";
});

document.getElementById("restoreBtn").addEventListener("click", () => {
  document.getElementById("restoreFile").click();
});

// Which site a backup's chats belong to, when the chats themselves don't say:
// the old single-site organizers named their files chatgpt-organizer-backup-* / claude-organizer-backup-*.
function guessBackupPlatform(fileName) {
  const n = (fileName || "").toLowerCase();
  if (n.includes("claude")) return "claude";
  if (n.includes("chatgpt") || n.includes("gpt")) return "chatgpt";
  return null;
}

function normName(s) { return (s || "").trim().toLowerCase(); }

// Adds a backup into what's already here. Folders with the same name in the same place are
// merged into one; everything else is added. Existing chats keep their current folder.
function mergeBackup(backup, defaultPlatform) {
  const bFolders = Object.values(backup.folders || {});
  const idMap = {}; // backup folder id → folder id here
  let foldersAdded = 0, foldersMerged = 0;

  // Parents before children, so each folder's parent is already mapped.
  const depth = f => { let d = 0, cur = f, seen = new Set(); while (cur && cur.parentId && !seen.has(cur.id)) { seen.add(cur.id); cur = backup.folders[cur.parentId]; d++; } return d; };
  bFolders.sort((x, y) => depth(x) - depth(y)).forEach(f => {
    const parentHere = f.parentId ? (idMap[f.parentId] || null) : null;
    if (DATA.folders[f.id]) { idMap[f.id] = f.id; return; } // same backup restored before
    const twin = Object.values(DATA.folders).find(x => (x.parentId || null) === parentHere && normName(x.name) === normName(f.name));
    if (twin) { idMap[f.id] = twin.id; foldersMerged++; return; }
    const copy = Object.assign({}, f, { parentId: parentHere });
    DATA.folders[copy.id] = copy;
    idMap[f.id] = copy.id;
    foldersAdded++;
  });

  let chatsAdded = 0, chatsKept = 0;
  Object.values(backup.chats || {}).forEach(c => {
    if (DATA.chats[c.id]) { chatsKept++; return; }
    const platform = PLATFORMS[c.platform] ? c.platform : defaultPlatform;
    DATA.chats[c.id] = Object.assign({}, c, { platform, folderId: c.folderId ? (idMap[c.folderId] || null) : null });
    chatsAdded++;
  });
  return { foldersAdded, foldersMerged, chatsAdded, chatsKept };
}

document.getElementById("restoreFile").addEventListener("change", async (e) => {
  const file = e.target.files[0];
  e.target.value = "";
  if (!file) return;
  let backup;
  try {
    backup = JSON.parse(await file.text());
  } catch (err) {
    showImportStatus("Could not parse that file — expected a backup .json from Export backup.", true);
    return;
  }
  if (!backup || typeof backup !== "object" || !backup.folders || !backup.chats) {
    showImportStatus("That file doesn't look like a valid backup (missing folders/chats).", true);
    return;
  }

  const unlabeled = Object.values(backup.chats).some(c => !PLATFORMS[c.platform]);
  let defaultPlatform = guessBackupPlatform(file.name);
  if (unlabeled && !defaultPlatform) {
    defaultPlatform = confirm(`Which organizer did "${file.name}" come from?\n\nOK = Claude organizer\nCancel = ChatGPT organizer`) ? "claude" : "chatgpt";
  }
  defaultPlatform = defaultPlatform || "chatgpt";

  const isEmpty = Object.keys(DATA.folders).length === 0 && Object.keys(DATA.chats).length === 0;
  if (!isEmpty && !confirm(
    `Add this backup${unlabeled ? ` (as ${PLATFORMS[defaultPlatform].label} chats)` : ""} to what's already here?\n\n` +
    "Folders with the same name in the same place are merged into one. Nothing already here is moved or overwritten."
  )) return;

  const r = mergeBackup(backup, defaultPlatform);
  await persist();
  showImportStatus(`Restored: ${r.foldersAdded} folder${r.foldersAdded === 1 ? "" : "s"} added, ${r.foldersMerged} merged with same-named folders, ${r.chatsAdded} chat${r.chatsAdded === 1 ? "" : "s"} added${r.chatsKept ? `, ${r.chatsKept} already here (left as they were)` : ""}.`);
  renderAll();
});

// ---------- Sync open tabs (both sites) ----------

document.getElementById("syncTabsBtn").addEventListener("click", async () => {
  const tabs = await chrome.tabs.query({});
  const prefixes = { chatgpt: await getProjectPrefixes("chatgpt"), claude: await getProjectPrefixes("claude") };
  let updated = 0, added = 0;

  tabs.forEach(tab => {
    const platform = platformOfUrl(tab.url);
    if (!platform || isShareUrl(tab.url)) return;
    const chatId = extractConversationId(tab.url);
    if (!chatId) return;

    const title = cleanTabTitle(tab.title, prefixes[platform], platform);
    const existing = DATA.chats[chatId];
    if (existing) {
      if (!existing.platform) existing.platform = platform;
      if (!existing.titleLocked && existing.title !== title) { existing.title = title; updated++; }
    } else {
      DATA.chats[chatId] = { id: chatId, title, folderId: null, createTime: Date.now() / 1000, platform };
      added++;
    }
  });

  await persist();
  showImportStatus(`Synced open ChatGPT and Claude tabs: updated ${updated} title${updated === 1 ? "" : "s"}, added ${added} new chat${added === 1 ? "" : "s"} to Unorganized.`);
  renderAll();
});

// ---------- Export current chat (two formats; site detected from the active tab) ----------
// "For AI" → .md for pasting/uploading into another LLM or program.
// "Readable" → self-contained .html for people.

const READERS = {
  chatgpt: {
    fetchFull: (tabId, id) => fetchChatGptConversation(tabId, id),
    parse: data => chatgptConversationToMessages(data),
    fullTitle: data => data.title,
    fromPage: tabId => extractChatGptPageMessages(tabId),
    findInExport: (list, id) => list.find(c => (c.conversation_id || c.id) === id),
    partialNote: "Long canvas/writing blocks may be incomplete"
  },
  claude: {
    fetchFull: (tabId, id) => fetchClaudeConversationViaPage(tabId, id),
    parse: data => claudeConversationToMessages(data),
    fullTitle: data => (data.name || "").trim(),
    fromPage: tabId => extractClaudePageMessages(tabId),
    findInExport: (list, id) => list.find(c => (c.uuid || c.id) === id),
    partialNote: "Artifacts and very long replies may be incomplete"
  }
};

let pendingExport = null; // { chatId, format, meta, platform } waiting on the export-file picker

function deliverExport(format, messages, meta) {
  const base = safeFileName(meta.title);
  if (format === "ai") {
    downloadTextFile(`${base} (for AI).md`, messagesToAiMarkdown(messages, meta), "text/markdown");
  } else {
    downloadTextFile(`${base}.html`, messagesToHtml(messages, meta), "text/html");
  }
}

function formatLabel(format) { return format === "ai" ? "AI-ready .md" : "readable .html"; }

async function exportCurrentChat(format) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const platform = tab && platformOfUrl(tab.url);
  if (!platform) {
    showImportStatus("Switch to an open ChatGPT or Claude chat (or a share link) in this window first, then export.", true);
    return;
  }
  const site = PLATFORMS[platform], reader = READERS[platform];
  const title = cleanTabTitle(tab.title, await getProjectPrefixes(platform), platform);
  const meta = { title, url: tab.url.split("?")[0], source: site.label };

  // Public share page: read the rendered page.
  if (isShareUrl(tab.url)) {
    showImportStatus("Reading the shared conversation...");
    const result = await reader.fromPage(tab.id);
    if (!result.ok) { showImportStatus(`Couldn't read this share page (${result.error}).`, true); return; }
    deliverExport(format, result.messages, { ...meta, completeness: "partial" });
    showImportStatus(`Downloaded ${formatLabel(format)} for "${title}" (${result.messages.length} messages, via share page).`);
    return;
  }

  const chatId = extractConversationId(tab.url);
  if (!chatId) {
    showImportStatus(`That tab doesn't look like a ${site.label} conversation yet — open an actual chat first.`, true);
    return;
  }

  // 1. Full conversation, read from inside the open tab — complete, no Share needed.
  showImportStatus(`Reading this ${site.label} conversation...`);
  const direct = await reader.fetchFull(tab.id, chatId);
  if (direct.ok) {
    const messages = reader.parse(direct.data);
    if (messages.length) {
      const t = reader.fullTitle(direct.data) || title;
      deliverExport(format, messages, { ...meta, title: t, completeness: "full" });
      showImportStatus(`Downloaded ${formatLabel(format)} for "${t}" (${messages.length} messages, full conversation).`);
      return;
    }
  }

  // 2. Fall back to the text rendered on the open page.
  const fromPage = await reader.fromPage(tab.id);
  if (fromPage.ok) {
    deliverExport(format, fromPage.messages, { ...meta, completeness: "partial" });
    showImportStatus(`Downloaded ${formatLabel(format)} for "${title}" (${fromPage.messages.length} messages, read from the page — full read unavailable: ${direct.error || "empty"}). ${reader.partialNote}; use your export file if you need every word.`, true);
    return;
  }

  // 3. Last resort: the official export file.
  pendingExport = { chatId, format, meta, platform };
  showImportStatus(`Couldn't read this chat directly (${direct.error || "empty"}; page: ${fromPage.error}). Select your ${site.label} export (conversations.json) to pull the full text of "${title}".`, true);
  document.getElementById("exportChatFile").click();
}

document.getElementById("exportAiBtn").addEventListener("click", () => exportCurrentChat("ai"));
document.getElementById("exportHtmlBtn").addEventListener("click", () => exportCurrentChat("html"));

document.getElementById("exportChatFile").addEventListener("change", async (e) => {
  const file = e.target.files[0];
  e.target.value = "";
  if (!file || !pendingExport) return;
  const { chatId, format, meta, platform } = pendingExport;
  pendingExport = null;
  const site = PLATFORMS[platform], reader = READERS[platform];

  let parsed;
  try {
    parsed = JSON.parse(await file.text());
  } catch (err) {
    showImportStatus(`Could not parse that file as JSON. Use conversations.json from your ${site.label} data export.`, true);
    return;
  }
  const match = reader.findInExport(exportList(parsed), chatId);
  if (!match) {
    showImportStatus(`"${meta.title}" isn't in that export yet — export fresh data (${site.exportHelp}) and try again.`, true);
    return;
  }
  const messages = reader.parse(match);
  deliverExport(format, messages, { ...meta, completeness: "full" });
  showImportStatus(`Downloaded ${formatLabel(format)} for "${meta.title}" (${messages.length} messages).`);
});

// ---------- Project names (kept per site) ----------

document.getElementById("projectPrefixesBtn").addEventListener("click", async () => {
  const platform = ACTIVE_PLATFORM || "chatgpt";
  const label = PLATFORMS[platform].label;
  const current = (await getProjectPrefixes(platform)).join("\n");
  const input = prompt(
    `${label} project names to strip from chat titles (one per line, exact match, case-sensitive).` +
    (ACTIVE_PLATFORM ? "" : "\n\nTip: switch to a Claude tab first to edit Claude's list instead."),
    current
  );
  if (input === null) return;
  const list = input.split("\n").map(s => s.trim()).filter(Boolean);
  await setProjectPrefixes(platform, list);
  showImportStatus(`Saved ${list.length} ${label} project name${list.length === 1 ? "" : "s"}. Click "Sync open tabs" to apply it to already-known titles.`);
});

// ---------- Active-site indicator ----------

async function refreshActiveSite() {
  let tab;
  try { [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); } catch (e) { tab = null; }
  ACTIVE_PLATFORM = tab ? platformOfUrl(tab.url) : null;
  const el = document.getElementById("activeSite");
  if (!el) return;
  if (ACTIVE_PLATFORM) {
    const p = PLATFORMS[ACTIVE_PLATFORM];
    el.innerHTML = `On ${p.label} <span class="pf-badge pf-${p.id}">${p.badge}</span>`;
    el.title = `Export and project names act on ${p.label}`;
  } else {
    el.textContent = "Not on ChatGPT or Claude";
    el.title = "Open a ChatGPT or Claude chat to export it";
  }
}

chrome.tabs.onActivated.addListener(refreshActiveSite);
chrome.tabs.onUpdated.addListener((id, info, tab) => { if (tab.active && (info.url || info.status === "complete")) refreshActiveSite(); });
chrome.windows.onFocusChanged.addListener(refreshActiveSite);

document.getElementById("expandAllBtn").addEventListener("click", async () => {
  Object.values(DATA.folders).forEach(f => { f.collapsed = false; });
  await persist();
  renderTree();
});

document.getElementById("collapseAllBtn").addEventListener("click", async () => {
  Object.values(DATA.folders).forEach(f => { f.collapsed = true; });
  await persist();
  renderTree();
});

document.getElementById("newFolderBtn").addEventListener("click", async () => {
  const name = prompt("New folder name:");
  if (!name) return;
  const fid = newId("f");
  DATA.folders[fid] = { id: fid, name, parentId: null, order: Date.now() };
  await persist();
  renderAll();
});

document.getElementById("searchBox").addEventListener("input", renderChatList);

document.getElementById("platformFilter").addEventListener("change", async (e) => {
  PLATFORM_FILTER = e.target.value;
  await setPlatformFilter(PLATFORM_FILTER);
  renderAll();
});

document.getElementById("chatSortSelect").addEventListener("change", async (e) => {
  CHAT_SORT = e.target.value;
  await setSortPrefs({ chatSort: CHAT_SORT, folderSort: FOLDER_SORT });
  renderAll();
});

// ---------- Backup reminder ----------

const BACKUP_REMINDER_DAYS = 14;

async function checkBackupReminder() {
  const el = document.getElementById("backupReminder");
  const hasData = Object.keys(DATA.folders).length > 0 || Object.keys(DATA.chats).length > 0;
  if (!hasData) { el.style.display = "none"; return; }

  const dismissUntil = await getBackupDismissUntil();
  if (dismissUntil && Date.now() < dismissUntil) { el.style.display = "none"; return; }

  const last = await getLastBackupTime();
  const daysSince = last ? (Date.now() - last) / (1000 * 60 * 60 * 24) : Infinity;

  if (daysSince < BACKUP_REMINDER_DAYS) { el.style.display = "none"; return; }

  const msg = last
    ? `It's been ${Math.floor(daysSince)} days since your last backup.`
    : "You haven't exported a backup yet.";
  el.innerHTML = `<span>${msg} Your folder organization only lives in this browser.</span><span><button id="backupNowBtn">Export backup now</button> <button id="backupLaterBtn" class="dismiss-btn">Not now</button></span>`;
  el.style.display = "flex";
  document.getElementById("backupNowBtn").addEventListener("click", () => {
    document.getElementById("exportBtn").click();
  });
  document.getElementById("backupLaterBtn").addEventListener("click", async () => {
    await setBackupDismissUntil(Date.now() + 3 * 24 * 60 * 60 * 1000); // snooze 3 days
    el.style.display = "none";
  });
}

// ---------- Init ----------

(async function init() {
  DATA = await loadData();
  // Chats saved before the merge are ChatGPT chats — label them once.
  let stamped = 0;
  Object.values(DATA.chats).forEach(c => { if (!PLATFORMS[c.platform]) { c.platform = "chatgpt"; stamped++; } });
  if (stamped) await persist();
  PLATFORM_FILTER = await getPlatformFilter();
  document.getElementById("platformFilter").value = PLATFORM_FILTER;
  refreshActiveSite();
  const sortPrefs = await getSortPrefs();
  CHAT_SORT = sortPrefs.chatSort;
  FOLDER_SORT = sortPrefs.folderSort;
  document.getElementById("chatSortSelect").value = CHAT_SORT;
  renderAll();
  checkBackupReminder();
})();
