# YouTube Transcript Rater

Current version: **4.0.0**

A standalone Chrome extension (Manifest V3) that extracts a YouTube video's transcript and rates it against your personal consumption criteria, using your existing ChatGPT or Claude subscription — no separate API key or cost. Kept deliberately separate from your ChatGPT/Claude Organizer extension so a bug in one can't crash the other.

---

## What it does (current feature set)

1. **On a YouTube video page:** click the floating ⭐ button (top-right, near the video info panel) to extract the transcript and rate it against your saved criteria.
2. **From anywhere in Chrome:** click the extension icon, paste a YouTube link (full URL, `youtu.be` short link, or Shorts link — with or without `https://`) into the popup, and click "Rate this video" — no need to have the video open at all.
3. Either way, a fresh ChatGPT or Claude chat opens automatically, the transcript + your criteria get typed in, and the reply is parsed into a score breakdown.
4. **Results display:**
   - On YouTube itself: inline in the floating panel.
   - From the popup flow: the same rich panel appears on whichever tab you were on when you submitted the link (via on-demand script injection — see Technical Notes), *and* a system notification fires as a reliable fallback.
5. Every successful rating saves a lightweight record (title, URL, scores, summary — never the full transcript) to local history, viewable and exportable as Markdown from the popup.
6. A dedicated **"Upload Transcript"** button in the results panel downloads the raw transcript as a `.txt` file — point your browser's download folder at a Drive/Dropbox-synced folder once, and this (and the library export) land there automatically.
7. Automated ChatGPT chats are renamed to start with `YT transcript_<video title>`, so they group together in your sidebar (best-effort — see Known Limitations).

---

## Setup

1. `chrome://extensions` → enable **Developer mode** → **Load unpacked** → select this folder.
2. Make sure you're logged into ChatGPT and/or Claude.ai in this browser profile.
3. Click the extension icon → pick a platform (ChatGPT or Claude) → expand **Consumption criteria** and paste in your guidelines → **Save Settings**.

## Using it

- **On a video:** click ⭐ (top-right of the page).
- **From anywhere:** click the extension icon → paste a link → **Rate this video**. You can close the popup immediately; results appear as an in-page panel on your source tab (if the page allows script injection) and/or a notification.
- **Recent ratings:** expand "Recent ratings" in the popup.
- **Export Library (.md):** dumps your full rating history into one Markdown file.

---

## Technical notes worth knowing

- **Transcript extraction has two methods, tried in order.** First, reading caption data directly from the page (`ytInitialPlayerResponse`) — fast, no UI interaction. If YouTube's backend returns an empty response (a real anti-scraping measure YouTube has tightened over time), it falls back to clicking "Show transcript" and scraping the panel.
- **YouTube's transcript panel now uses a different component** (`<transcript-segment-view-model>`) than older documentation describes (`ytd-transcript-segment-renderer`); both are supported.
- **The "Show transcript" click requires a genuinely trusted click** — YouTube ignores script-dispatched click events entirely for this button. The extension uses Chrome's debugger protocol (`chrome.debugger`) to simulate a real trusted click when a plain synthetic click doesn't work (you'll briefly see Chrome's "extension started debugging this browser" bar — expected). It remembers per-browser which method actually works, to skip the doomed attempt on future runs.
- **Chat completion detection watches the actual reply text until it stabilizes**, rather than inferring completion from a "stop generating" button's timing (which proved unreliable for both very fast and very slow replies).
- **Ratings are parsed from a simple line-based format** (`OVERALL_SCORE:`, `VERDICT:`, `SCORES:`, `SUMMARY:`), not JSON — deliberately, since asking a chat UI (no enforced JSON mode) for strict JSON is fragile against ordinary natural-language quotes/apostrophes/commas.
- **The "rate any link" popup flow opens the YouTube tab as active** (briefly visible, then focus is restored) — YouTube appears to defer full rendering of interactive elements like the transcript panel on tabs that are never actually visible.
- **The in-page result panel for non-YouTube tabs uses the `activeTab` permission**, not a broad "access to all websites" grant — the panel script is injected only into the specific tab you were on, only at the moment you click "Rate" in the popup, and nowhere else. This cannot work on `chrome://` pages, the Chrome Web Store, or other browser-internal pages — no extension can inject scripts there, by design; the notification is the fallback for those cases.
- **MV3 service worker keep-alive.** A rating job can take a few minutes; a small periodic no-op keeps the background service worker alive for the duration (Chrome can otherwise kill it after ~30s of inactivity).
- **New conversation per rating**, by design — reusing an arbitrary open chat tab risked hijacking a conversation you were already having.
- **Debugging tools:**
  - YouTube tab console: `[YTR]` logs.
  - ChatGPT/Claude tab console: `[YTR-chatgpt]` / `[YTR-claude]` logs.
  - Background service worker console (separate from any page's console — open via `chrome://extensions` → this extension's card → **"service worker"** link): `[YTR-bg]` logs.
  - **Test Selectors** button in the popup checks ChatGPT/Claude selectors live and reports what's found/missing.
  - **Always hard-refresh (F5) any already-open tab** after reloading the extension — Chrome does not re-inject content scripts into tabs that were already open.

---

## Known limitations

- Very long transcripts are trimmed to ~60k characters before being sent.
- Rename automation selectors are speculative (ChatGPT's sidebar structure is less stable than its composer) — check the service worker console for `[YTR-chatgpt] rename skipped/failed` logs if grouping isn't working.
- **Non-English video titles/transcripts** may produce inconsistent ChatGPT sidebar-naming results (the actual rating/scoring is unaffected — this is specifically about ChatGPT's own title-generation behavior on mixed-language input). Treated as a known, low-priority limitation for now.
- **`chrome://` pages and other browser-internal pages can never show the in-page result panel** — this is a hard Chrome restriction with no workaround; the notification fallback covers this case.
- ChatGPT Plus / Claude Pro have rolling usage limits on their chat interfaces — rating many videos back-to-back could hit that cap (unlike a paid API, which has no such limit but costs per call).

## Roadmap

- **Full transcript library.** Current history (title/URL/scores/summary, capped at 300 entries, exportable as Markdown) is the seed for a proper searchable "what have I watched and was it worth it" library — a dedicated design pass is still pending.
- Extend conversation-renaming/grouping to Claude.ai (currently ChatGPT-only).
- Merge into the main organizer extension once this is stable.
- Possible: automatic cloud sync (e.g. Google Drive) — deferred in favor of the manual-download-into-synced-folder approach, which needs no OAuth/API integration.

---

## Full version history

### v1.0.0 — Initial build
First working version, matching the original 4-phase concept: a floating ⭐ button on YouTube video pages that extracts the transcript (by clicking "Show transcript" and scraping `ytd-transcript-segment-renderer` elements) and rates it against saved criteria by calling the **Anthropic API directly** (using a user-supplied API key entered in the popup).

### v2.0.0 — Pivot: chat automation instead of a paid API
**Why:** already paying for ChatGPT/Claude subscriptions — no interest in a second, separate API cost. After comparing alternatives (n8n middleman, a local LLM via Ollama, free-tier cloud APIs, manual copy-paste), the choice was automated copy-paste into the existing ChatGPT/Claude web UI.
**Changed:** removed the Anthropic API entirely; added `content-chatgpt.js` and `content-claude.js` (typing the prompt into the chat, clicking send, waiting for and scraping the reply) and a `background.js` orchestrator (opens a fresh chat tab, builds the prompt, coordinates the exchange, parses the reply). Popup redesigned: platform selector instead of an API key field, plus a "close tab after rating" option. A "copy prompt to clipboard" fallback was added so a failed automation step never leaves you fully stuck.
*(Note: two early reliability fixes — diagnostic tool methodology and an `aria-disabled` detection fix, both described below — landed in this same 2.0.0 package before per-fix version bumping became a consistent practice.)*
- **Diagnostic methodology fix:** the built-in selector-testing tool was checking the send button, stop button, and reply container on a completely *empty* chat — where the send button doesn't render/enable until text is typed, and the other two can't exist without a real exchange. Fixed to type a harmless test string first, and to mark those two checks "N/A" rather than a false failure on an empty chat.
- **`aria-disabled` fix:** ChatGPT communicates its send button's enabled state via the `aria-disabled` attribute, not the native HTML `disabled` property — the enabled-check was updated to look at both, and an explicit `input` event was added after text insertion as extra insurance that the page's own JS notices the change.

### v2.0.1 — Version-bump discipline established
**Why:** after several fixes above, confusion arose over whether reloading the extension was actually picking up new code, since the version number never changed.
**Changed:** no functional change — just started bumping the manifest version on every single fix from this point on, so a reload's effect is always visually verifiable.

### v3.0.0 — First transcript-extraction hardening pass, plus six requested features
**Why:** testing the real click-automation flow surfaced that YouTube's transcript button doesn't respond to any script-dispatched click at all — only a genuinely trusted user click works.
**Changed:** introduced `chrome.debugger`-based trusted-click simulation as an escalation when a plain synthetic click fails (with the `debugger` permission, and Chrome's "being debugged" bar as a visible side effect). Also bundled six requested improvements in the same release:
1. Remembers (via `chrome.storage.local`) which click method worked last time, skipping the doomed attempt on future runs.
2. Collapsible "Summary" section in the results panel.
3. Floating button repositioned to top-right, near the video info panel.
4. New "rate any YouTube link" field added to the popup (background-tab pipeline + notification on completion).
5. Best-effort ChatGPT sidebar conversation renaming (`YT transcript_<title>` prefix).
6. Lightweight rating-history storage, laying groundwork for a future transcript library.

### v3.1.0 – v3.1.10 — The transcript-extraction debugging chain
A long back-and-forth chasing why transcript extraction kept failing on specific videos, each fix uncovering the next real cause:
- **3.1.1:** JSON parse-error messages now include the model's actual raw reply text, so failures are self-diagnosing without needing console access; increased transcript-panel poll patience.
- **3.1.2:** fixed "Show transcript" sometimes being invisible because the description wasn't expanded yet — added a visibility check plus auto-expand-first logic.
- **3.1.3:** discovered the description's "more" toggle could itself resolve to a *hidden decoy* element (`id="expand-sizer"`, a YouTube-internal text-measurement clone) — added debugger-click escalation for that button too, not just "Show transcript" itself.
- **3.1.4:** added rich diagnostic logging (every candidate match's id/tag/visibility) once the decoy-element problem needed more visibility to solve conclusively.
- **3.1.5:** replaced fuzzy text-matching for the "more" button with a direct, stable selector (`tp-yt-paper-button#expand`) based on real markup inspected via DevTools.
- **3.1.6:** discovered **duplicate `id="expand"` elements** on the same page (invalid HTML, but real) — fixed by scanning all matches and picking the one that's actually visible, instead of trusting the first DOM match.
- **3.1.8:** increased segment-detection patience from ~20s to ~40s, since the click was succeeding but the panel itself was slow to populate (confirmed via periodic "still waiting..." progress logs).
- **3.1.9 — the big one:** discovered YouTube had rolled out an entirely new transcript panel component (`<transcript-segment-view-model>`), replacing the older `ytd-transcript-segment-renderer` this code was originally built against. Updated the segment selector and text-extraction logic to support both — this fixed extraction outright, rather than just buying more patience.
- **3.1.10:** fixed a genuine bug in the custom JSON parser ("no matching closing brace") by making its brace-counting **string-aware** — it was miscounting braces that happened to appear inside quoted string values (e.g. within the summary text).

### v3.2.0 — Replaced JSON output with a simple line-based format
**Why:** asking a chat UI (with no enforced JSON mode, unlike the real API) to emit strictly valid JSON is inherently fragile — ordinary natural-language quotes, apostrophes, or commas in the summary kept breaking JSON syntax, no matter how the parser was patched. This was a deliberate root-cause fix.
**Changed:** the prompt now asks for `OVERALL_SCORE:` / `VERDICT:` / `SCORES:` / `SUMMARY:` on separate lines instead of a JSON object; parsing switched to simple regex extraction, immune to the characters that kept breaking JSON.

### v3.2.1 — Fixed a new race condition the format change exposed
**Why:** the simpler format made replies generate *faster*, exposing a latent bug: the old completion-detection logic (wait for a "stop generating" button to appear, then disappear) could grab an empty reply bubble before any text had streamed in, if the whole reply finished before the detection logic even got a chance to observe the button's lifecycle.
**Changed:** replaced button-timing-based detection with **content-stability detection** — watch the actual reply text until it stops changing across several consecutive checks. Works correctly regardless of how fast or slow the reply is.

### v3.2.2 — Extended the reply-wait timeout
**Why:** a genuine reply took longer than the 60-second timeout allowed — not a bug, just an under-sized patience budget for longer transcripts/prompts.
**Changed:** extended to 3 minutes, with periodic progress logging so a long wait is visibly still working rather than looking stuck.

### v3.2.3 — Fixed the button not appearing after search/homepage navigation
**Why:** the content script only injected on `/watch` URLs. Clicking a video from YouTube's search results or homepage is a client-side navigation (no real page load), so a tab that started on a non-matching URL never got the script injected at all.
**Changed:** broadened injection to all of `youtube.com`, with the button showing/hiding itself based on the current page path.

### v3.3.0 — Upload Transcript button, and a prompt-based title hint
- **"Upload Transcript" button** added to the results panel — downloads the raw transcript as `.txt`. "Cloud storage" is achieved simply by pointing the browser's download folder at a Drive/Dropbox-synced local folder — no OAuth or API integration needed.
- **Conversation-title hint added directly into the prompt text**, as a second, complementary attempt (alongside the existing DOM-based sidebar rename) at getting ChatGPT to title the conversation `YT transcript_<title>`.

### v3.3.1 — Fixed shortened-link rejection and a tab-timing messaging error
- **`youtu.be` and Shorts links were rejected** by a URL validator that only recognized full `youtube.com/watch?v=` URLs — replaced with a proper normalizer supporting both.
- **Added retry logic** around messaging a freshly-opened tab, after a real Chrome "message channel closed before a response was received" error appeared — likely caused by messaging a tab before its content script was fully ready despite the existing wait.

### v3.3.2 — Fixed missing-scheme URLs and background-tab rendering
- **URLs pasted without `https://`** (e.g. `youtube.com/watch?v=...`) were rejected outright, since `new URL()` throws on a bare domain with no scheme — now auto-prepended if missing.
- **The "rate any link" YouTube tab was opened in the background** (`active: false`), which appears to make YouTube defer full rendering/interactivity of the transcript panel for tabs that are never visible — every prior successful extraction had happened on a tab actively being looked at. Changed to open the tab active (briefly visible), then restore focus to whatever tab was active before.

### v4.0.0 — Side panel replaces the popup; HTML-escaping hardening
**Why:** planning ahead across cloud storage, design, and technical robustness surfaced that the small transient popup was cramped for a growing feature set (rate-any-link, settings, history, diagnostics), and that the results panel was inserting transcript/model text directly into HTML without escaping it — a real (if low-severity, since it's your own content) self-XSS gap.
**Changed:**
- Replaced `popup.html`/`.js`/`.css` entirely with `sidepanel.html`/`.js`/`.css`, using Chrome's native Side Panel API. Clicking the toolbar icon now opens a persistent, roomier panel instead of a small dropdown — same functionality, more space, and a natural home for the planned transcript library.
- The floating ⭐ button and in-page result panel on YouTube are **unaffected** — this only changes the toolbar-icon experience.
- **New trade-off worth knowing:** the side panel can stay open across tab switches (unlike the old popup, which closed immediately) — submitting a link after switching tabs may mean the `activeTab` grant (tied to whichever tab was active when the panel was opened) doesn't cover the new tab, so the in-page panel injection can fail silently in that case, falling back to the notification only (same as the `chrome://` page restriction).
- **Security hardening:** all dynamic text inserted into the results panel (scores, verdict, summary, error messages) is now HTML-escaped before rendering, closing a self-XSS gap where transcript or model-generated text containing HTML-like characters could have been interpreted as markup.

### v3.4.0 — Full in-page result panel for the "rate any link" flow
**Why:** the popup-triggered flow only showed a bare system notification (final score, no detail, no way to expand the summary or use the Upload Transcript button) — nowhere near as useful as the on-YouTube experience.
**Changed:** results now render as the same rich panel (score bars, collapsible summary, Upload Transcript button) on whichever tab submitted the link. Implemented using the **already-granted `activeTab` permission** — on-demand script injection into the one specific source tab, at the exact moment "Rate this video" is clicked — rather than requesting a much broader "access to all websites" permission (a real trade-off that was discussed explicitly before choosing this narrower approach). Shared rendering code was extracted into `panel-ui.js`, used by both the YouTube in-page button and this new universal panel, so both stay visually consistent from one source. Note: this cannot work on `chrome://` pages or other browser-internal pages — a hard Chrome restriction, not a bug — the notification remains the fallback there.

---

## File structure

- `manifest.json` — extension configuration
- `background.js` — service worker: orchestrates chat automation, the "rate any link" pipeline, history, notifications
- `content-youtube.js` — runs on YouTube: floating button, transcript extraction
- `content-chatgpt.js` / `content-claude.js` — automate typing the prompt and reading the reply on each platform
- `content-universal.js` — injected on demand into the tab that submitted a "rate any link" job
- `panel-ui.js` — shared result-panel rendering, used by both `content-youtube.js` and `content-universal.js`
- `sidepanel.html` / `sidepanel.js` / `sidepanel.css` — settings, "rate any link" input, history, diagnostics (opens from the toolbar icon)
- `content.css` — floating button/panel styling
- `icon16.png` / `icon48.png` / `icon128.png` — extension icons
