// background.js — orchestrates: build prompt -> open/find chat tab -> submit -> collect -> parse

// Clicking the toolbar icon opens the side panel (replaces the old popup).
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

const PLATFORM_CONFIG = {
  chatgpt: { urlPattern: 'https://chatgpt.com/*', newChatUrl: 'https://chatgpt.com/' },
  claude: { urlPattern: 'https://claude.ai/*', newChatUrl: 'https://claude.ai/new' },
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'RATE_VIA_CHAT') {
    handleRateViaChat(message.transcript, message.meta)
      .then((response) => sendResponse(response))
      .catch((err) => sendResponse({ error: err.message }));
    return true;
  }
  if (message.type === 'RATE_FROM_URL') {
    handleRateFromUrl(message.url)
      .then((response) => sendResponse(response))
      .catch((err) => sendResponse({ error: err.message }));
    return true;
  }
  if (message.type === 'GET_HISTORY') {
    chrome.storage.local.get(['ratingHistory']).then(({ ratingHistory }) => {
      sendResponse({ history: ratingHistory || [] });
    });
    return true;
  }
  if (message.type === 'RUN_DIAGNOSTIC') {
    runDiagnosticForPlatform(message.platform)
      .then((response) => sendResponse(response))
      .catch((err) => sendResponse({ error: err.message }));
    return true;
  }
  if (message.type === 'DEBUGGER_CLICK') {
    const tabId = sender.tab?.id;
    if (!tabId) {
      sendResponse({ ok: false, error: 'No tab ID available for debugger click.' });
      return true;
    }
    debuggerClick(tabId, message.x, message.y)
      .then(() => sendResponse({ ok: true }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }
});

function buildPrompt(transcript, meta, criteria, conversationTitle) {
  const trimmed = transcript.length > 60000 ? transcript.slice(0, 60000) : transcript;
  return `Please title this conversation exactly: ${conversationTitle}

You are helping me triage YouTube videos against my personal consumption criteria.

MY CRITERIA:
${criteria}

VIDEO TITLE: ${meta?.title || 'Unknown'}
VIDEO URL: ${meta?.url || 'Unknown'}

TRANSCRIPT:
${trimmed}

Respond using EXACTLY this plain-text format, one field per line, nothing before OVERALL_SCORE and nothing after SUMMARY (no JSON, no markdown, no code fences):

OVERALL_SCORE: <integer 0-10>
VERDICT: <short phrase, a few words>
SCORES: <criterion label>=<0-10>; <criterion label>=<0-10>; <criterion label>=<0-10>
SUMMARY: <2-3 sentence explanation referencing specifics from the transcript>

Derive the SCORES criteria from my guidelines above (2-6 short labels). Keep VERDICT on one line, on its own — do not use semicolons or line breaks inside it. SUMMARY can be the last line and may be longer.`;
}

function extractStructuredResult(text) {
  // Line-based format instead of JSON — structurally immune to quotes,
  // apostrophes, or commas in natural writing breaking parsing, unlike
  // asking a chat UI (no strict-JSON-mode available) to emit valid JSON.
  const overallMatch = text.match(/OVERALL_SCORE:\s*(\d+)/i);
  const verdictMatch = text.match(/VERDICT:\s*(.+)/i);
  const scoresMatch = text.match(/SCORES:\s*(.+)/i);
  const summaryMatch = text.match(/SUMMARY:\s*([\s\S]+)/i);

  if (!overallMatch || !scoresMatch) {
    throw new Error(
      'PARSE_ERROR: could not find OVERALL_SCORE/SCORES fields in the reply. What the chat actually said (first 400 chars): "' +
        text.slice(0, 400) +
        '"'
    );
  }

  const overallScore = parseInt(overallMatch[1], 10);
  const verdict = verdictMatch ? verdictMatch[1].trim() : '';
  const summary = summaryMatch ? summaryMatch[1].trim() : '';

  const scores = {};
  scoresMatch[1]
    .split(';')
    .map((pair) => pair.trim())
    .filter(Boolean)
    .forEach((pair) => {
      const eqIndex = pair.lastIndexOf('=');
      if (eqIndex === -1) return;
      const label = pair.slice(0, eqIndex).trim();
      const value = parseInt(pair.slice(eqIndex + 1).trim(), 10);
      if (label && !Number.isNaN(value)) scores[label] = value;
    });

  if (Object.keys(scores).length === 0) {
    throw new Error(
      'PARSE_ERROR: found a SCORES line but could not parse any label=value pairs from it. Raw SCORES line: "' +
        scoresMatch[1].slice(0, 400) +
        '"'
    );
  }

  return { overallScore, verdict, scores, summary };
}

async function openNewChatTab(platform) {
  const config = PLATFORM_CONFIG[platform];
  const tab = await chrome.tabs.create({ url: config.newChatUrl, active: false });
  await new Promise((resolve) => {
    function listener(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
  // Give the SPA a moment to hydrate after "complete" fires.
  await new Promise((r) => setTimeout(r, 3000));
  return tab;
}

// ---------- Keep the MV3 service worker alive during long operations ----------
// Chrome can terminate a background service worker after ~30s of inactivity,
// even with a pending async chain. A periodic trivial API call resets that
// idle timer for the duration of a rating job (which can take 1-2 minutes).

function startKeepAlive() {
  const id = setInterval(() => {
    chrome.storage.local.get('__keepalive').catch(() => {});
  }, 20000);
  return () => clearInterval(id);
}

async function handleRateViaChat(transcript, meta) {
  const stopKeepAlive = startKeepAlive();
  try {
    return await handleRateViaChatInner(transcript, meta);
  } finally {
    stopKeepAlive();
  }
}

async function handleRateViaChatInner(transcript, meta) {
  const { criteria, platform, closeTabAfter } = await chrome.storage.local.get([
    'criteria',
    'platform',
    'closeTabAfter',
  ]);

  if (!criteria) {
    throw new Error('No rating criteria set. Click the extension icon to add your guidelines.');
  }

  const target = platform || 'chatgpt';
  const conversationTitle = 'YT transcript_' + (meta?.title || 'video').slice(0, 60);
  const prompt = buildPrompt(transcript, meta, criteria, conversationTitle);
  let tab;

  try {
    tab = await openNewChatTab(target);
    const response = await sendMessageWithRetry(tab.id, {
      type: 'SUBMIT_PROMPT',
      prompt,
      conversationTitle,
    });

    if (!response) {
      throw new Error('NO_RESPONSE: the chat tab did not respond. It may still be loading — try again in a moment.');
    }
    if (response.error) {
      throw new Error(response.error);
    }

    const result = extractStructuredResult(response.text);

    if (closeTabAfter && tab) {
      chrome.tabs.remove(tab.id).catch(() => {});
    }

    await saveToHistory(meta, result);

    return { result };
  } catch (err) {
    // Always hand back the raw prompt so the UI can offer a manual copy-paste fallback.
    return { error: err.message, promptText: prompt, tabId: tab ? tab.id : null };
  }
}

// ---------- Rate any YouTube link, not just the one currently open ----------
// Opens a background tab for the link, reuses the same extraction + rating
// pipeline as the in-page floating button, then notifies the user when done
// (since the panel or tab that submitted the job may already be closed by then).

function normalizeYoutubeUrl(rawUrl) {
  let candidate = (rawUrl || '').trim();
  if (!/^https?:\/\//i.test(candidate)) {
    candidate = 'https://' + candidate;
  }

  let u;
  try {
    u = new URL(candidate);
  } catch {
    return null;
  }

  const host = u.hostname.replace(/^www\./, '').replace(/^m\./, '');

  if (host === 'youtu.be') {
    const id = u.pathname.split('/').filter(Boolean)[0];
    return id ? `https://www.youtube.com/watch?v=${id}` : null;
  }

  if (host === 'youtube.com') {
    if (u.pathname === '/watch' && u.searchParams.has('v')) {
      return `https://www.youtube.com/watch?v=${u.searchParams.get('v')}`;
    }
    const shortsMatch = u.pathname.match(/^\/shorts\/([^/?]+)/);
    if (shortsMatch) {
      return `https://www.youtube.com/watch?v=${shortsMatch[1]}`;
    }
    const liveMatch = u.pathname.match(/^\/live\/([^/?]+)/);
    if (liveMatch) {
      return `https://www.youtube.com/watch?v=${liveMatch[1]}`;
    }
  }

  return null;
}

async function openYoutubeTab(url) {
  // Made ACTIVE (not background) deliberately: YouTube appears to defer full
  // rendering/interactivity of things like the transcript panel for tabs that
  // are never actually visible. The in-page floating button never hit this
  // because that tab is always the one the user is already looking at.
  const tab = await chrome.tabs.create({ url, active: true });
  await new Promise((resolve) => {
    function listener(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
  await new Promise((r) => setTimeout(r, 2500)); // let the SPA hydrate
  return tab;
}

function restoreFocus(previousActiveTabId) {
  if (previousActiveTabId) {
    chrome.tabs.update(previousActiveTabId, { active: true }).catch(() => {});
  }
}

async function sendMessageWithRetry(tabId, message, retries = 2, delayMs = 2000) {
  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch (e) {
    if (retries > 0) {
      console.log('[YTR-bg] sendMessage failed (', e.message, '), retrying in', delayMs, 'ms —', retries, 'attempt(s) left');
      await new Promise((r) => setTimeout(r, delayMs));
      return sendMessageWithRetry(tabId, message, retries - 1, delayMs);
    }
    throw e;
  }
}

async function handleRateFromUrl(url) {
  const stopKeepAlive = startKeepAlive();
  try {
    return await handleRateFromUrlInner(url);
  } finally {
    stopKeepAlive();
  }
}

async function injectUniversalPanel(tabId) {
  // Must happen while activeTab access is still valid for this tab — i.e.
  // right when the side panel message arrives, before any lengthy async work.
  // Wrapped defensively: some pages (chrome://, the Web Store, PDF viewer)
  // never allow script injection at all — fail silently and fall back to
  // the notification, which always fires regardless.
  try {
    await chrome.scripting.insertCSS({ target: { tabId }, files: ['content.css'] });
    await chrome.scripting.executeScript({ target: { tabId }, files: ['panel-ui.js', 'content-universal.js'] });
    return true;
  } catch (e) {
    console.log('[YTR-bg] could not inject universal panel into tab', tabId, ':', e.message);
    return false;
  }
}

function showResultInSourceTab(tabId, canShowPanel, payload) {
  if (!canShowPanel || !tabId) return;
  chrome.tabs.sendMessage(tabId, { type: 'SHOW_RESULT_READY', ...payload }).catch(() => {});
}

async function handleRateFromUrlInner(url) {
  const normalizedUrl = normalizeYoutubeUrl(url);
  if (!normalizedUrl) {
    const err =
      'That doesn\'t look like a YouTube video URL (expected something like https://www.youtube.com/watch?v=..., a youtu.be link, or a Shorts link).';
    notify('Rating failed', err);
    return { error: err };
  }

  // Grab the source tab and attempt injection immediately, while the
  // activeTab grant from opening the side panel is still fresh. Note: if the
  // panel was opened on a different tab and the user then switched tabs
  // before submitting, this grant won't cover the newly-active tab — the
  // notification fallback below still fires regardless.
  const [sourceTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const sourceTabId = sourceTab?.id;
  const canShowPanel = sourceTabId ? await injectUniversalPanel(sourceTabId) : false;

  let ytTab;
  try {
    ytTab = await openYoutubeTab(normalizedUrl);

    const extraction = await sendMessageWithRetry(ytTab.id, { type: 'EXTRACT_TRANSCRIPT_ONLY' });

    if (!extraction || extraction.error) {
      const err = extraction?.error || 'Could not extract a transcript from that video.';
      chrome.tabs.remove(ytTab.id).catch(() => {});
      restoreFocus(sourceTabId);
      notify('Rating failed', err);
      showResultInSourceTab(sourceTabId, canShowPanel, { error: err });
      return { error: err };
    }

    const ratingResponse = await handleRateViaChat(extraction.transcript, extraction.meta);
    chrome.tabs.remove(ytTab.id).catch(() => {});
    restoreFocus(sourceTabId);

    if (ratingResponse.error) {
      notify('Rating failed', ratingResponse.error);
      showResultInSourceTab(sourceTabId, canShowPanel, {
        error: ratingResponse.error,
        promptText: ratingResponse.promptText,
      });
      return ratingResponse;
    }

    const { overallScore, verdict } = ratingResponse.result;
    notify(
      `Rated: ${overallScore}/10 — ${verdict || ''}`,
      extraction.meta?.title || url
    );
    showResultInSourceTab(sourceTabId, canShowPanel, {
      result: ratingResponse.result,
      meta: extraction.meta,
      transcript: extraction.transcript,
    });
    return ratingResponse;
  } catch (err) {
    if (ytTab) chrome.tabs.remove(ytTab.id).catch(() => {});
    restoreFocus(sourceTabId);
    notify('Rating failed', err.message);
    showResultInSourceTab(sourceTabId, canShowPanel, { error: err.message });
    return { error: err.message };
  }
}

function notify(title, message) {
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icon128.png',
    title,
    message: message || '',
  });
}

async function saveToHistory(meta, result) {
  try {
    const { ratingHistory } = await chrome.storage.local.get(['ratingHistory']);
    const history = ratingHistory || [];
    history.unshift({
      title: meta?.title || 'Unknown',
      url: meta?.url || '',
      overallScore: result.overallScore,
      verdict: result.verdict,
      summary: result.summary,
      scores: result.scores,
      timestamp: Date.now(),
    });
    // Cap history length so storage stays small — this is metadata only,
    // never the full transcript text.
    const capped = history.slice(0, 300);
    await chrome.storage.local.set({ ratingHistory: capped });
  } catch (e) {
    console.log('[YTR-bg] failed to save history (non-fatal):', e.message);
  }
}

async function runDiagnosticForPlatform(platform) {
  const tab = await openNewChatTab(platform);
  const response = await chrome.tabs.sendMessage(tab.id, { type: 'DIAGNOSTIC' });
  return { results: response?.results, tabId: tab.id };
}

// ---------- Debugger-simulated trusted click ----------
// Some sites (YouTube's transcript button included) only respond to genuinely
// trusted browser input, not script-dispatched DOM events. Attaching the
// debugger protocol and sending a real Input.dispatchMouseEvent produces a
// click indistinguishable from a real user click — this briefly shows Chrome's
// "extension started debugging this browser" bar, which clears on detach.

function cdpSendCommand(tabId, method, params = {}) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand({ tabId }, method, params, (result) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(result);
      }
    });
  });
}

function debuggerAttach(tabId) {
  return new Promise((resolve, reject) => {
    chrome.debugger.attach({ tabId }, '1.3', () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve();
      }
    });
  });
}

function debuggerDetach(tabId) {
  return new Promise((resolve) => {
    chrome.debugger.detach({ tabId }, () => resolve());
  });
}

async function debuggerClick(tabId, x, y) {
  console.log('[YTR-bg] attaching debugger to tab', tabId, 'for click at', x, y);
  try {
    await debuggerAttach(tabId);
    console.log('[YTR-bg] debugger attached successfully');
  } catch (e) {
    console.error('[YTR-bg] debugger attach failed:', e.message);
    throw e;
  }
  try {
    await cdpSendCommand(tabId, 'Input.dispatchMouseEvent', {
      type: 'mouseMoved',
      x,
      y,
    });
    await cdpSendCommand(tabId, 'Input.dispatchMouseEvent', {
      type: 'mousePressed',
      x,
      y,
      button: 'left',
      clickCount: 1,
    });
    await cdpSendCommand(tabId, 'Input.dispatchMouseEvent', {
      type: 'mouseReleased',
      x,
      y,
      button: 'left',
      clickCount: 1,
    });
    console.log('[YTR-bg] mouse events dispatched successfully');
  } catch (e) {
    console.error('[YTR-bg] dispatchMouseEvent failed:', e.message);
    throw e;
  } finally {
    await debuggerDetach(tabId);
    console.log('[YTR-bg] debugger detached');
  }
}
