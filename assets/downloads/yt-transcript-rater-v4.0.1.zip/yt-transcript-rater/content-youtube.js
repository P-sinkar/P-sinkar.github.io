// content-youtube.js — runs on youtube.com/watch pages

console.log('[YTR] content-youtube.js loaded on', location.href);

const sleep = (ms) => new Promise((res) => setTimeout(res, ms));

// ---------- Preferred method: read captions directly from page data ----------
// YouTube embeds a JSON blob (ytInitialPlayerResponse) with direct caption-track
// URLs. This avoids clicking any UI at all, sidestepping YouTube's internal
// jsaction dispatch system that made the button-click approach unreliable.

function findPlayerResponseJson() {
  const scripts = document.querySelectorAll('script');
  for (const script of scripts) {
    const text = script.textContent;
    if (text && text.includes('ytInitialPlayerResponse')) {
      const match = text.match(/ytInitialPlayerResponse\s*=\s*(\{.*?\})\s*;/s);
      if (match) {
        try {
          return JSON.parse(match[1]);
        } catch (e) {
          console.log('[YTR] found ytInitialPlayerResponse but failed to parse it:', e.message);
        }
      }
    }
  }
  return null;
}

function parseTranscriptXml(xmlString) {
  const doc = new DOMParser().parseFromString(xmlString, 'text/xml');
  const textNodes = Array.from(doc.getElementsByTagName('text'));
  return textNodes
    .map((n) => n.textContent || '')
    .join(' ')
    .replace(/\s+/g, ' ')
    .trim();
}

async function fetchTranscriptViaPageData() {
  const playerResponse = findPlayerResponseJson();
  const tracks = playerResponse?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
  if (!tracks || tracks.length === 0) {
    console.log('[YTR] no caption tracks found in ytInitialPlayerResponse');
    return null;
  }

  const track =
    tracks.find((t) => t.languageCode?.startsWith('en') && t.kind !== 'asr') ||
    tracks.find((t) => t.languageCode?.startsWith('en')) ||
    tracks[0];

  console.log('[YTR] using caption track:', track.languageCode, track.kind || 'manual', track.name?.simpleText || '');

  // Try the structured json3 format first.
  try {
    const jsonUrl = track.baseUrl + (track.baseUrl.includes('fmt=') ? '' : '&fmt=json3');
    const res = await fetch(jsonUrl);
    if (res.ok) {
      const raw = await res.text();
      console.log('[YTR] json3 response length:', raw.length);
      if (raw.trim().length > 0) {
        const data = JSON.parse(raw);
        const text = (data.events || [])
          .flatMap((e) => e.segs || [])
          .map((s) => s.utf8 || '')
          .join('')
          .replace(/\n/g, ' ')
          .replace(/\s+/g, ' ')
          .trim();
        if (text) return text;
        console.log('[YTR] json3 parsed but produced no text, trying XML fallback');
      } else {
        console.log('[YTR] json3 response was empty, trying XML fallback');
      }
    } else {
      console.log('[YTR] json3 fetch failed with status', res.status, '— trying XML fallback');
    }
  } catch (e) {
    console.log('[YTR] json3 fetch/parse threw:', e.message, '— trying XML fallback');
  }

  // Fall back to YouTube's default XML timedtext format (no fmt param).
  try {
    const xmlRes = await fetch(track.baseUrl);
    if (xmlRes.ok) {
      const xmlText = await xmlRes.text();
      console.log('[YTR] XML fallback response length:', xmlText.length);
      const parsed = parseTranscriptXml(xmlText);
      if (parsed) return parsed;
    } else {
      console.log('[YTR] XML fallback fetch failed with status', xmlRes.status);
    }
  } catch (e) {
    console.log('[YTR] XML fallback fetch threw:', e.message);
  }

  return null;
}

// ---------- Fallback method: click "Show transcript" and scrape the panel ----------
// Kept only as a backup in case the page-data method above ever fails (e.g. a
// structural change to ytInitialPlayerResponse). Known to be less reliable
// because YouTube's transcript button routes through internal jsaction dispatch
// rather than a plain click listener.

function fireFullClick(el) {
  const opts = { bubbles: true, cancelable: true, view: window };
  el.dispatchEvent(new PointerEvent('pointerdown', opts));
  el.dispatchEvent(new MouseEvent('mousedown', opts));
  el.dispatchEvent(new PointerEvent('pointerup', opts));
  el.dispatchEvent(new MouseEvent('mouseup', opts));
  el.click();
}

function isVisible(el) {
  if (!el) return false;
  if (el.hidden) return false;
  if (el.getAttribute && el.getAttribute('aria-hidden') === 'true') return false;
  const rect = el.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}

function isMeasurementDecoy(el) {
  // YouTube names invisible "sizer" clones (used only to measure text width)
  // with "-sizer" in their id — e.g. "expand-sizer". These share the exact
  // same text/aria-label as the real button, so text matching alone can't
  // tell them apart; the id naming convention can.
  return (el.id || '').toLowerCase().includes('sizer');
}

function findButtonByText(text) {
  const target = text.toLowerCase();

  // Collect ALL matches rather than returning the first — see isMeasurementDecoy.
  const candidates = document.querySelectorAll('button, tp-yt-paper-button, yt-button-shape, a, [role="button"]');
  const tagMatches = [];
  for (const el of candidates) {
    if (isMeasurementDecoy(el)) continue;
    const label = (el.getAttribute('aria-label') || el.textContent || '').trim().toLowerCase();
    if (label === target || label.includes(target)) tagMatches.push(el);
  }
  const visibleTagMatch = tagMatches.find(isVisible);
  if (visibleTagMatch) return visibleTagMatch;

  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
  let node = walker.currentNode;
  const leafMatches = [];
  while (node) {
    if (node.childElementCount === 0 && !isMeasurementDecoy(node)) {
      const label = (node.textContent || '').trim().toLowerCase();
      if (label === target) {
        const clickable = node.closest('button, [role="button"], a, tp-yt-paper-button, yt-button-shape') || node;
        if (!isMeasurementDecoy(clickable)) leafMatches.push(clickable);
      }
    }
    node = walker.nextNode();
  }
  const visibleLeafMatch = leafMatches.find(isVisible);
  if (visibleLeafMatch) return visibleLeafMatch;

  console.log(
    `[YTR] findButtonByText("${text}") — tagMatches:`,
    tagMatches.map((el) => ({ id: el.id, tag: el.tagName, visible: isVisible(el) })),
    'leafMatches:',
    leafMatches.map((el) => ({ id: el.id, tag: el.tagName, visible: isVisible(el) }))
  );

  // Last resort: return any non-decoy match at all, even if visibility is unclear.
  return tagMatches[0] || leafMatches[0] || null;
}

async function debuggerClickElement(el) {
  el.scrollIntoView({ block: 'center', behavior: 'instant' });
  await sleep(300);
  const rect = el.getBoundingClientRect();
  const x = Math.round(rect.left + rect.width / 2);
  const y = Math.round(rect.top + rect.height / 2);
  console.log('[YTR] requesting debugger click at', x, y, 'on element:', el.tagName, el.outerHTML.slice(0, 350));
  const response = await chrome.runtime.sendMessage({ type: 'DEBUGGER_CLICK', x, y });
  console.log('[YTR] debugger click response:', response);
  if (!response || !response.ok) {
    throw new Error('Debugger click failed: ' + (response?.error || 'unknown error'));
  }
}

async function findDescriptionExpandButton() {
  // A single immediate check can catch this element mid-render (zero size for
  // a brief moment before YouTube finishes laying it out) — poll instead of
  // checking once.
  const start = Date.now();
  while (Date.now() - start < 5000) {
    const candidates = document.querySelectorAll('tp-yt-paper-button#expand');
    const visible = Array.from(candidates).find(isVisible);
    if (visible) return visible;
    await sleep(250);
  }
  console.log('[YTR] no visible #expand found after polling for 5s, falling back to text search');
  return findButtonByText('...more') || findButtonByText('more');
}

async function findVisibleTranscriptButton() {
  let btn = findButtonByText('show transcript');
  if (btn && isVisible(btn)) return btn;

  console.log('[YTR] "Show transcript" not visible yet, expanding description first');
  const moreBtn = await findDescriptionExpandButton();
  if (!moreBtn) {
    console.log('[YTR] no "more" expand control found either');
    return btn && isVisible(btn) ? btn : null;
  }

  fireFullClick(moreBtn);
  await sleep(600);
  btn = findButtonByText('show transcript');
  if (btn && isVisible(btn)) return btn;

  // Some pages need a trusted click even for the description's "more" toggle.
  console.log('[YTR] plain click on "more" did not reveal it, trying debugger click on "more"');
  try {
    await debuggerClickElement(moreBtn);
    await sleep(600);
  } catch (e) {
    console.log('[YTR] debugger click on "more" failed:', e.message);
  }
  btn = findButtonByText('show transcript');
  return btn && isVisible(btn) ? btn : null;
}

// YouTube has at least two different transcript panel implementations in the
// wild: the newer "transcript-segment-view-model" custom element, and the
// older "ytd-transcript-segment-renderer". Support both.
const TRANSCRIPT_SEGMENT_SELECTOR = 'transcript-segment-view-model, ytd-transcript-segment-renderer';

async function openTranscriptPanel() {
  const btn = await findVisibleTranscriptButton();
  if (!btn) {
    console.log('[YTR] could not find a visible "Show transcript" control at all');
    return false;
  }

  // Remember which click method actually worked last time, so we don't waste
  // time retrying a plain click we already know YouTube will ignore.
  const { ytClickMethod } = await chrome.storage.local.get('ytClickMethod');

  if (ytClickMethod !== 'debugger') {
    fireFullClick(btn);
    await sleep(800);
    if (document.querySelectorAll(TRANSCRIPT_SEGMENT_SELECTOR).length > 0) {
      console.log('[YTR] plain synthetic click opened the panel');
      chrome.storage.local.set({ ytClickMethod: 'plain' }).catch(() => {});
      return true;
    }
  } else {
    console.log('[YTR] skipping plain click attempt (remembered that debugger click is needed here)');
  }

  console.log('[YTR] using debugger-simulated click');
  try {
    await debuggerClickElement(btn);
    await sleep(1000);
  } catch (e) {
    console.log('[YTR] debugger click threw an error:', e.message);
    return false;
  }
  chrome.storage.local.set({ ytClickMethod: 'debugger' }).catch(() => {});
  return true;
}

async function fetchTranscriptViaUiClick() {
  await openTranscriptPanel();

  // Even a real human click has a visible delay before the panel actually
  // populates, and this environment has shown real network flakiness (slow/
  // failed requests to YouTube's CDN) — give it substantial room (up to 40s)
  // rather than failing while the panel is still genuinely loading.
  let segments = [];
  for (let i = 0; i < 80; i++) {
    segments = document.querySelectorAll(TRANSCRIPT_SEGMENT_SELECTOR);
    if (segments.length > 0) break;
    if (i > 0 && i % 10 === 0) {
      console.log(`[YTR] still waiting for transcript segments... (${(i * 0.5).toFixed(0)}s elapsed)`);
    }
    await sleep(500);
  }
  console.log('[YTR] (fallback) transcript segments found:', segments.length);

  if (segments.length === 0) return null;

  const lines = Array.from(segments).map((seg) => {
    // New component: text lives in a .ytAttributedStringHost span.
    // Old component: text lives in a .segment-text element.
    const textEl = seg.querySelector('.ytAttributedStringHost') || seg.querySelector('.segment-text') || seg;
    return textEl.textContent.trim();
  });

  return lines.join(' ').replace(/\s+/g, ' ').trim();
}

async function extractTranscript() {
  try {
    const apiText = await fetchTranscriptViaPageData();
    if (apiText) {
      console.log('[YTR] transcript obtained via page data, length:', apiText.length);
      return apiText;
    }
  } catch (e) {
    console.log('[YTR] page-data transcript method threw an error:', e.message);
  }

  console.log('[YTR] falling back to UI click method');
  const uiText = await fetchTranscriptViaUiClick();
  if (uiText) {
    console.log('[YTR] transcript obtained via UI click, length:', uiText.length);
    return uiText;
  }

  throw new Error(
    'Could not extract a transcript via page data or the transcript panel. This video may not have captions/transcript available.'
  );
}

function getVideoMeta() {
  const titleEl = document.querySelector('h1.ytd-watch-metadata yt-formatted-string, h1.title yt-formatted-string');
  const title = titleEl ? titleEl.textContent.trim() : document.title;
  return { title, url: location.href };
}

// Lets the background script pull a transcript out of this tab even when the
// user isn't the one clicking the floating button here — used by the "rate any
// link" flow triggered from the popup.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'EXTRACT_TRANSCRIPT_ONLY') {
    (async () => {
      try {
        const transcript = await extractTranscript();
        const meta = getVideoMeta();
        sendResponse({ transcript, meta });
      } catch (err) {
        sendResponse({ error: err.message });
      }
    })();
    return true;
  }
});

// ---------- Floating UI ----------

function createFloatingButton() {
  if (document.getElementById('ytr-fab')) {
    console.log('[YTR] button already exists, skipping');
    return;
  }
  if (!document.body) {
    console.log('[YTR] document.body not ready yet');
    return;
  }

  const fab = document.createElement('button');
  fab.id = 'ytr-fab';
  fab.title = 'Rate this video\'s transcript';
  fab.textContent = '⭐';
  document.body.appendChild(fab);

  const panel = document.createElement('div');
  panel.id = 'ytr-panel';
  panel.style.display = 'none';
  document.body.appendChild(panel);

  fab.addEventListener('click', () => handleRateClick(fab, panel));
  console.log('[YTR] floating button injected successfully');
}

// renderPanel, scoreBar, and renderErrorWithFallback now live in panel-ui.js
// (shared with content-universal.js) — loaded before this file per manifest.json.

async function handleRateClick(fab, panel) {
  fab.disabled = true;
  fab.classList.add('ytr-loading');
  ytrRenderPanel(panel, `<div class="ytr-header">Reading transcript…<span class="ytr-close">✕</span></div>`);
  panel.querySelector('.ytr-close').addEventListener('click', () => (panel.style.display = 'none'));

  try {
    const transcript = await extractTranscript();
    const meta = getVideoMeta();

    const { platform } = await chrome.storage.local.get('platform');
    const platformName = platform === 'claude' ? 'Claude' : 'ChatGPT';
    ytrRenderPanel(panel, `<div class="ytr-header">Rating with ${platformName}…<span class="ytr-close">✕</span></div>`);
    panel.querySelector('.ytr-close').addEventListener('click', () => (panel.style.display = 'none'));

    const response = await chrome.runtime.sendMessage({
      type: 'RATE_VIA_CHAT',
      transcript,
      meta,
    });

    if (!response || response.error) {
      ytrRenderErrorWithFallback(panel, response?.error || 'Unknown error while rating transcript.', response?.promptText);
      return;
    }

    ytrRenderResult(panel, response.result, meta, transcript);
  } catch (err) {
    ytrRenderErrorWithFallback(panel, err.message, null);
  } finally {
    fab.disabled = false;
    fab.classList.remove('ytr-loading');
  }
}

function removeFloatingUi() {
  const fab = document.getElementById('ytr-fab');
  if (fab) fab.remove();
  const panel = document.getElementById('ytr-panel');
  if (panel) panel.remove();
}

function isWatchPage() {
  // /watch is the classic URL; /live/<id> is how YouTube links livestreams
  // and premieres (both current and ended-and-archived) — same underlying
  // watch-page infrastructure, just a different vanity path.
  return location.pathname === '/watch' || location.pathname.startsWith('/live/');
}

function maybeInjectButton() {
  if (isWatchPage()) {
    createFloatingButton();
  } else {
    removeFloatingUi();
  }
}

maybeInjectButton();

// YouTube is an SPA — clicking a video from search results, the homepage, or
// a recommendation is a client-side navigation, not a real page load. Since
// the content script now runs on all of youtube.com (not just /watch pages),
// this always has a chance to run and pick up the transition.
let lastUrl = location.href;
new MutationObserver(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    setTimeout(maybeInjectButton, 1000);
  }
}).observe(document.body, { childList: true, subtree: true });
