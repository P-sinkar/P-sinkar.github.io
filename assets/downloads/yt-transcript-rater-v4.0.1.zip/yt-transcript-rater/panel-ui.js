// panel-ui.js — shared floating-panel rendering, used by content-youtube.js
// (the in-page button on YouTube) and content-universal.js (the on-demand
// panel injected into whichever tab submitted a "rate any link" job from the
// popup). Keeping this in one file means both surfaces show identical UI and
// only need fixing in one place.

function ytrEscapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}

function ytrRenderPanel(panel, html) {
  panel.innerHTML = html;
  panel.style.display = 'block';
}

function ytrScoreBar(label, score) {
  const pct = Math.max(0, Math.min(10, Number(score) || 0)) * 10;
  return `
    <div class="ytr-score-row">
      <div class="ytr-score-label">${ytrEscapeHtml(label)}</div>
      <div class="ytr-score-track"><div class="ytr-score-fill" style="width:${pct}%"></div></div>
      <div class="ytr-score-value">${ytrEscapeHtml(score)}/10</div>
    </div>`;
}

function ytrRenderErrorWithFallback(panel, message, promptText) {
  const copyButtonHtml = promptText
    ? `<button class="ytr-copy-btn">Copy prompt to clipboard</button>
       <div class="ytr-hint">Paste this directly into ChatGPT or Claude yourself.</div>`
    : '';

  ytrRenderPanel(
    panel,
    `<div class="ytr-header">Automation failed<span class="ytr-close">✕</span></div>
     <div class="ytr-error">${ytrEscapeHtml(message)}</div>
     ${copyButtonHtml}`
  );
  panel.querySelector('.ytr-close').addEventListener('click', () => (panel.style.display = 'none'));

  const copyBtn = panel.querySelector('.ytr-copy-btn');
  if (copyBtn) {
    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(promptText);
        copyBtn.textContent = 'Copied!';
        setTimeout(() => (copyBtn.textContent = 'Copy prompt to clipboard'), 1500);
      } catch (e) {
        copyBtn.textContent = 'Copy failed — select manually';
      }
    });
  }
}

function ytrRenderResult(panel, result, meta, transcriptText) {
  const { overallScore, verdict, scores, summary } = result;
  const scoreRows = Object.entries(scores || {})
    .map(([label, score]) => ytrScoreBar(label, score))
    .join('');

  ytrRenderPanel(
    panel,
    `<div class="ytr-header">
       <span>Transcript Rating</span>
       <span class="ytr-close">✕</span>
     </div>
     <div class="ytr-overall">
       <span class="ytr-overall-score">${ytrEscapeHtml(overallScore)}/10</span>
       <span class="ytr-verdict">${ytrEscapeHtml(verdict || '')}</span>
     </div>
     ${scoreRows}
     <div class="ytr-summary-toggle">Summary <span class="ytr-summary-arrow">▾</span></div>
     <div class="ytr-summary" style="display:none">${ytrEscapeHtml(summary || '')}</div>
     <button class="ytr-upload-btn">Upload Transcript</button>
     <div class="ytr-hint ytr-upload-hint"></div>`
  );
  panel.querySelector('.ytr-close').addEventListener('click', () => (panel.style.display = 'none'));

  const summaryToggle = panel.querySelector('.ytr-summary-toggle');
  const summaryEl = panel.querySelector('.ytr-summary');
  summaryToggle.addEventListener('click', () => {
    const isOpen = summaryEl.style.display !== 'none';
    summaryEl.style.display = isOpen ? 'none' : 'block';
    summaryToggle.querySelector('.ytr-summary-arrow').textContent = isOpen ? '▾' : '▴';
  });

  const uploadBtn = panel.querySelector('.ytr-upload-btn');
  const uploadHint = panel.querySelector('.ytr-upload-hint');
  uploadBtn.addEventListener('click', () => {
    const safeTitle = (meta?.title || 'transcript').replace(/[\\/:*?"<>|]/g, '').slice(0, 80);
    const content = `# ${meta?.title || 'Untitled'}\n\nURL: ${meta?.url || ''}\nDate: ${new Date().toLocaleString()}\n\n---\n\n${transcriptText || ''}`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${safeTitle}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    uploadHint.textContent = "Downloaded — set your browser's download folder to a cloud-synced folder for automatic upload.";
  });
}
