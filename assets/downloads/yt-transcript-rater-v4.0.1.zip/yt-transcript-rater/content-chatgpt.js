// content-chatgpt.js — runs on chatgpt.com
// If automation breaks, this is the file to fix. Update the selector lists
// below first — that's almost always all that's needed after a ChatGPT UI change.
//
// Known quirk: ChatGPT's send button communicates its enabled state via the
// aria-disabled attribute, not the native HTML "disabled" property — always
// check both (see isElementDisabled below).

const CHATGPT_SELECTORS = {
  input: [
    '#prompt-textarea',
    'div[contenteditable="true"][translate="no"]',
    'form div[contenteditable="true"]',
  ],
  sendButton: [
    'button[data-testid="send-button"]',
    '#composer-submit-button',
    'button[aria-label="Send message"]',
    'button[aria-label="Send prompt"]',
  ],
  stopButton: [
    'button[data-testid="stop-button"]',
    'button[aria-label="Stop generating"]',
    'button[aria-label="Stop streaming"]',
  ],
  assistantMessage: ['[data-message-author-role="assistant"]'],
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function queryFirst(selectors) {
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el) return { el, sel };
  }
  return null;
}

function queryAllFirst(selectors) {
  for (const sel of selectors) {
    const els = document.querySelectorAll(sel);
    if (els.length > 0) return { els, sel };
  }
  return { els: [], sel: null };
}

function isElementDisabled(el) {
  return el.disabled === true || el.getAttribute('aria-disabled') === 'true';
}

function typeIntoInput(el, text) {
  el.focus();
  document.execCommand('selectAll', false, null);
  document.execCommand('insertText', false, text);
  // Some composers only react to a genuine input event rather than relying
  // solely on execCommand's built-in event dispatch — fire one explicitly.
  el.dispatchEvent(
    new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'insertText', data: text })
  );
}

async function waitFor(fn, timeoutMs = 15000, intervalMs = 300) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const result = fn();
    if (result) return result;
    await sleep(intervalMs);
  }
  return null;
}

async function insertPrompt(text) {
  const found = await waitFor(() => queryFirst(CHATGPT_SELECTORS.input));
  if (!found) {
    throw new Error(
      'CHATGPT_INPUT_NOT_FOUND: could not find the message box. ChatGPT\'s UI may have changed — update CHATGPT_SELECTORS.input in content-chatgpt.js.'
    );
  }
  typeIntoInput(found.el, text);
  await sleep(500);
}

async function clickSend() {
  const found = await waitFor(() => {
    const f = queryFirst(CHATGPT_SELECTORS.sendButton);
    return f && !isElementDisabled(f.el) ? f : null;
  }, 8000);
  if (!found) {
    throw new Error(
      'CHATGPT_SEND_BUTTON_NOT_FOUND_OR_DISABLED: the prompt text may not have registered, or the send button selector changed. Update CHATGPT_SELECTORS.sendButton.'
    );
  }
  found.el.click();
}

async function waitForStableResponse(initialCount, { maxWaitMs = 180000, stableChecks = 3, intervalMs = 400 } = {}) {
  // Instead of inferring completion from a transient "stop generating" button
  // (unreliable timing — it might disappear before we ever see it appear, or
  // never render at all for a very fast reply), watch the actual message text
  // until it stops changing across several consecutive checks. Works
  // correctly regardless of whether the reply takes 1 second or 3 minutes.
  const start = Date.now();
  let lastText = null;
  let stableCount = 0;
  let lastLoggedSecond = 0;

  while (Date.now() - start < maxWaitMs) {
    const elapsedSec = Math.floor((Date.now() - start) / 1000);
    if (elapsedSec - lastLoggedSecond >= 15) {
      console.log(`[YTR-chatgpt] still waiting for a stable reply... (${elapsedSec}s elapsed)`);
      lastLoggedSecond = elapsedSec;
    }

    const { els } = queryAllFirst(CHATGPT_SELECTORS.assistantMessage);
    if (els.length > initialCount) {
      const currentText = els[els.length - 1].textContent.trim();
      if (currentText.length > 0) {
        if (currentText === lastText) {
          stableCount++;
          if (stableCount >= stableChecks) return currentText;
        } else {
          stableCount = 0;
          lastText = currentText;
        }
      }
    }
    await sleep(intervalMs);
  }
  return lastText; // null if no content ever appeared, partial text if it timed out mid-stream
}

// ---------- Best-effort conversation renaming ----------
// Groups all transcript-rating chats under one recognizable prefix in the
// sidebar. This is speculative UI automation of ChatGPT's sidebar (more
// volatile than the composer), so any failure here is caught and logged only —
// it never blocks or fails the actual rating.

const RENAME_SELECTORS = {
  sidebarLink: ['nav a[href^="/c/"]', 'a[data-testid^="history-item"]'],
  optionsButton: ['button[aria-haspopup="menu"]', 'button[data-testid$="-options"]'],
};

function findMenuItemByText(text) {
  const items = document.querySelectorAll('[role="menuitem"]');
  const target = text.trim().toLowerCase();
  for (const el of items) {
    if ((el.textContent || '').trim().toLowerCase() === target) return el;
  }
  return null;
}

async function renameCurrentConversation(newTitle) {
  try {
    const link = queryFirst(RENAME_SELECTORS.sidebarLink);
    if (!link) {
      console.log('[YTR-chatgpt] rename skipped: could not find sidebar conversation entry');
      return;
    }
    const container = link.el.closest('li') || link.el.parentElement;
    const scopedOptionsBtn =
      (container && container.querySelector('button[aria-haspopup="menu"], button[data-testid$="-options"]')) ||
      queryFirst(RENAME_SELECTORS.optionsButton)?.el;
    if (!scopedOptionsBtn) {
      console.log('[YTR-chatgpt] rename skipped: could not find the "..." options button');
      return;
    }
    scopedOptionsBtn.click();
    await sleep(400);

    const renameItem = findMenuItemByText('Rename');
    if (!renameItem) {
      console.log('[YTR-chatgpt] rename skipped: could not find "Rename" menu item');
      return;
    }
    renameItem.click();
    await sleep(400);

    const input = (container && container.querySelector('input')) || document.querySelector('input[value]');
    if (!input) {
      console.log('[YTR-chatgpt] rename skipped: could not find the rename text input');
      return;
    }
    typeIntoInput(input, newTitle);
    await sleep(200);
    input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true, cancelable: true }));
    console.log('[YTR-chatgpt] renamed conversation to:', newTitle);
  } catch (e) {
    console.log('[YTR-chatgpt] renaming failed (non-fatal):', e.message);
  }
}

async function runDiagnostic() {
  const results = {};

  const inputFound = queryFirst(CHATGPT_SELECTORS.input);
  results.input = inputFound ? { ok: true, matchedSelector: inputFound.sel } : { ok: false };

  if (inputFound) {
    typeIntoInput(inputFound.el, 'diagnostic test — safe to ignore');
    await sleep(600);

    const sendFound = queryFirst(CHATGPT_SELECTORS.sendButton);
    const sendEnabled = sendFound && !isElementDisabled(sendFound.el);
    results.sendButton = sendEnabled
      ? { ok: true, matchedSelector: sendFound.sel }
      : { ok: false, note: sendFound ? 'found but reports disabled' : 'no element matched' };

    // Clean up the test text without sending anything.
    inputFound.el.focus();
    document.execCommand('selectAll', false, null);
    document.execCommand('delete', false, null);
    inputFound.el.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true }));
  } else {
    results.sendButton = { ok: false, note: 'skipped — input box not found' };
  }

  results.stopButton = {
    ok: null,
    note: 'only appears while a real reply is streaming — not testable on an empty chat',
  };
  results.assistantMessage = {
    ok: null,
    note: 'only appears after a real reply — not testable on an empty chat',
  };

  return results;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'SUBMIT_PROMPT') {
    (async () => {
      try {
        const initialCount = queryAllFirst(CHATGPT_SELECTORS.assistantMessage).els.length;
        console.log('[YTR-chatgpt] initial assistant message count:', initialCount);

        await insertPrompt(message.prompt);
        console.log('[YTR-chatgpt] prompt inserted');

        await clickSend();
        console.log('[YTR-chatgpt] send clicked, watching reply text until it stabilizes');

        const text = await waitForStableResponse(initialCount);
        if (!text) {
          throw new Error(
            'CHATGPT_RESPONSE_NOT_FOUND: no reply text ever appeared within the timeout. Update CHATGPT_SELECTORS.assistantMessage.'
          );
        }
        console.log('[YTR-chatgpt] response stabilized, length:', text.length);

        if (message.conversationTitle) {
          await renameCurrentConversation(message.conversationTitle);
        }
        sendResponse({ text });
      } catch (err) {
        console.log('[YTR-chatgpt] SUBMIT_PROMPT failed:', err.message);
        sendResponse({ error: err.message });
      }
    })();
    return true;
  }
  if (message.type === 'DIAGNOSTIC') {
    runDiagnostic().then((results) => sendResponse({ results }));
    return true;
  }
});
