// content-claude.js — runs on claude.ai
// If automation breaks, this is the file to fix. Update the selector lists
// below first — that's almost always all that's needed after a Claude.ai UI change.
// Note: data-cds="Prose" was confirmed as Claude's response container in earlier
// DevTools inspection — this is a design-system attribute and tends to be more
// stable than ordinary CSS classes, but verify it's still current before relying on it.
//
// Known quirk (shared with ChatGPT): React-based composers often communicate
// enabled/disabled via aria-disabled rather than the native "disabled" property —
// always check both (see isElementDisabled below).

const CLAUDE_SELECTORS = {
  input: [
    'div[contenteditable="true"].ProseMirror',
    'div[aria-label="Write your prompt to Claude"]',
    'div[contenteditable="true"]',
  ],
  sendButton: [
    'button[aria-label="Send Message"]',
    'button[aria-label="Send message"]',
  ],
  stopButton: [
    'button[aria-label="Stop Response"]',
    'button[aria-label="Stop response"]',
  ],
  assistantMessage: ['[data-cds="Prose"]'],
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function queryFirst(selectors) {
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el) return { el, sel };
  }
  return null;
}

function queryAllFirst(selectors) {
  for (const sel of selectors) {
    const els = document.querySelectorAll(sel);
    if (els.length > 0) return { els, sel };
  }
  return { els: [], sel: null };
}

function isElementDisabled(el) {
  return el.disabled === true || el.getAttribute('aria-disabled') === 'true';
}

function typeIntoInput(el, text) {
  el.focus();
  document.execCommand('selectAll', false, null);
  document.execCommand('insertText', false, text);
  el.dispatchEvent(
    new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'insertText', data: text })
  );
}

async function waitFor(fn, timeoutMs = 15000, intervalMs = 300) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const result = fn();
    if (result) return result;
    await sleep(intervalMs);
  }
  return null;
}

async function insertPrompt(text) {
  const found = await waitFor(() => queryFirst(CLAUDE_SELECTORS.input));
  if (!found) {
    throw new Error(
      'CLAUDE_INPUT_NOT_FOUND: could not find the message box. Claude.ai\'s UI may have changed — update CLAUDE_SELECTORS.input in content-claude.js.'
    );
  }
  typeIntoInput(found.el, text);
  await sleep(500);
}

async function clickSend() {
  const found = await waitFor(() => {
    const f = queryFirst(CLAUDE_SELECTORS.sendButton);
    return f && !isElementDisabled(f.el) ? f : null;
  }, 8000);
  if (!found) {
    throw new Error(
      'CLAUDE_SEND_BUTTON_NOT_FOUND_OR_DISABLED: the prompt text may not have registered, or the send button selector changed. Update CLAUDE_SELECTORS.sendButton.'
    );
  }
  found.el.click();
}

async function waitForStableResponse(initialCount, { maxWaitMs = 180000, stableChecks = 3, intervalMs = 400 } = {}) {
  // See content-chatgpt.js for rationale: watching text stabilize is more
  // robust than inferring completion from a transient stop-button's timing.
  const start = Date.now();
  let lastText = null;
  let stableCount = 0;
  let lastLoggedSecond = 0;

  while (Date.now() - start < maxWaitMs) {
    const elapsedSec = Math.floor((Date.now() - start) / 1000);
    if (elapsedSec - lastLoggedSecond >= 15) {
      console.log(`[YTR-claude] still waiting for a stable reply... (${elapsedSec}s elapsed)`);
      lastLoggedSecond = elapsedSec;
    }

    const { els } = queryAllFirst(CLAUDE_SELECTORS.assistantMessage);
    if (els.length > initialCount) {
      const currentText = els[els.length - 1].textContent.trim();
      if (currentText.length > 0) {
        if (currentText === lastText) {
          stableCount++;
          if (stableCount >= stableChecks) return currentText;
        } else {
          stableCount = 0;
          lastText = currentText;
        }
      }
    }
    await sleep(intervalMs);
  }
  return lastText;
}

async function runDiagnostic() {
  const results = {};

  const inputFound = queryFirst(CLAUDE_SELECTORS.input);
  results.input = inputFound ? { ok: true, matchedSelector: inputFound.sel } : { ok: false };

  if (inputFound) {
    typeIntoInput(inputFound.el, 'diagnostic test — safe to ignore');
    await sleep(600);

    const sendFound = queryFirst(CLAUDE_SELECTORS.sendButton);
    const sendEnabled = sendFound && !isElementDisabled(sendFound.el);
    results.sendButton = sendEnabled
      ? { ok: true, matchedSelector: sendFound.sel }
      : { ok: false, note: sendFound ? 'found but reports disabled' : 'no element matched' };

    inputFound.el.focus();
    document.execCommand('selectAll', false, null);
    document.execCommand('delete', false, null);
    inputFound.el.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true }));
  } else {
    results.sendButton = { ok: false, note: 'skipped — input box not found' };
  }

  results.stopButton = {
    ok: null,
    note: 'only appears while a real reply is streaming — not testable on an empty chat',
  };
  results.assistantMessage = {
    ok: null,
    note: 'only appears after a real reply — not testable on an empty chat',
  };

  return results;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'SUBMIT_PROMPT') {
    (async () => {
      try {
        const initialCount = queryAllFirst(CLAUDE_SELECTORS.assistantMessage).els.length;
        await insertPrompt(message.prompt);
        await clickSend();
        const text = await waitForStableResponse(initialCount);
        if (!text) {
          throw new Error(
            'CLAUDE_RESPONSE_NOT_FOUND: no reply text ever appeared within the timeout. Update CLAUDE_SELECTORS.assistantMessage.'
          );
        }
        sendResponse({ text });
      } catch (err) {
        sendResponse({ error: err.message });
      }
    })();
    return true;
  }
  if (message.type === 'DIAGNOSTIC') {
    runDiagnostic().then((results) => sendResponse({ results }));
    return true;
  }
});
