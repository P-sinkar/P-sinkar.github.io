const platformEl = document.getElementById('platform');
const closeTabEl = document.getElementById('closeTabAfter');
const criteriaEl = document.getElementById('criteria');
const statusEl = document.getElementById('status');
const toggleBtn = document.getElementById('toggleCriteria');
const criteriaWrap = document.getElementById('criteriaWrap');
const diagnoseBtn = document.getElementById('diagnose');
const diagnosticResults = document.getElementById('diagnosticResults');

const videoUrlEl = document.getElementById('videoUrl');
const rateUrlBtn = document.getElementById('rateUrl');
const rateStatusEl = document.getElementById('rateStatus');

const toggleHistoryBtn = document.getElementById('toggleHistory');
const historyWrap = document.getElementById('historyWrap');

toggleBtn.addEventListener('click', () => {
  const isOpen = criteriaWrap.style.display !== 'none';
  criteriaWrap.style.display = isOpen ? 'none' : 'block';
  toggleBtn.textContent = (isOpen ? '▸' : '▾') + ' Consumption criteria / rating guidelines';
});

toggleHistoryBtn.addEventListener('click', async () => {
  const isOpen = historyWrap.style.display !== 'none';
  if (isOpen) {
    historyWrap.style.display = 'none';
    toggleHistoryBtn.textContent = '▸ Recent ratings';
    return;
  }
  toggleHistoryBtn.textContent = '▾ Recent ratings';
  historyWrap.style.display = 'block';
  historyWrap.innerHTML = 'Loading…';
  const response = await chrome.runtime.sendMessage({ type: 'GET_HISTORY' });
  const history = response?.history || [];
  if (history.length === 0) {
    historyWrap.innerHTML = '<div class="ytr-history-empty">No ratings yet.</div>';
    return;
  }
  historyWrap.innerHTML = history
    .slice(0, 20)
    .map((h) => {
      const date = new Date(h.timestamp).toLocaleDateString();
      return `<div class="ytr-history-item">
        <div class="ytr-history-title">${escapeHtml(h.title)}</div>
        <div class="ytr-history-meta">${h.overallScore}/10 — ${escapeHtml(h.verdict || '')} · ${date}</div>
      </div>`;
    })
    .join('');
});

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}

async function load() {
  const { platform, criteria, closeTabAfter } = await chrome.storage.local.get([
    'platform',
    'criteria',
    'closeTabAfter',
  ]);
  if (platform) platformEl.value = platform;
  closeTabEl.checked = !!closeTabAfter;
  if (criteria) {
    criteriaEl.value = criteria;
    criteriaWrap.style.display = 'block';
    toggleBtn.textContent = '▾ Consumption criteria / rating guidelines';
  }
}

document.getElementById('save').addEventListener('click', async () => {
  await chrome.storage.local.set({
    platform: platformEl.value,
    closeTabAfter: closeTabEl.checked,
    criteria: criteriaEl.value.trim(),
  });
  statusEl.textContent = 'Saved.';
  setTimeout(() => (statusEl.textContent = ''), 2000);
});

rateUrlBtn.addEventListener('click', async () => {
  const url = videoUrlEl.value.trim();
  if (!url) {
    rateStatusEl.textContent = 'Paste a YouTube link first.';
    return;
  }
  rateUrlBtn.disabled = true;
  rateStatusEl.textContent = "Working on it — you don't need to keep this open, a notification will appear when done.";

  try {
    const response = await chrome.runtime.sendMessage({ type: 'RATE_FROM_URL', url });
    if (!response || response.error) {
      rateStatusEl.textContent = 'Error: ' + (response?.error || 'unknown error');
    } else {
      const { overallScore, verdict } = response.result;
      rateStatusEl.textContent = `Done — ${overallScore}/10 (${verdict || ''})`;
      videoUrlEl.value = '';
    }
  } catch (e) {
    // Popup may have been closed and reopened mid-flight; the background
    // notification is the source of truth in that case.
    rateStatusEl.textContent = 'Started — check for a notification when it finishes.';
  } finally {
    rateUrlBtn.disabled = false;
  }
});

document.getElementById('exportLibrary').addEventListener('click', async () => {
  const response = await chrome.runtime.sendMessage({ type: 'GET_HISTORY' });
  const history = response?.history || [];
  if (history.length === 0) {
    alert('No ratings saved yet — nothing to export.');
    return;
  }

  const lines = history
    .slice()
    .reverse() // oldest first, reads like a chronological log
    .map((h) => {
      const date = new Date(h.timestamp).toLocaleString();
      const scoreLines = Object.entries(h.scores || {})
        .map(([label, score]) => `  - ${label}: ${score}/10`)
        .join('\n');
      return `## ${h.title}

- URL: ${h.url}
- Date: ${date}
- Overall: ${h.overallScore}/10 — ${h.verdict || ''}
${scoreLines}

${h.summary || ''}

---
`;
    });

  const content = `# YouTube Transcript Library\n\nExported ${new Date().toLocaleString()}\n\n` + lines.join('\n');
  const blob = new Blob([content], { type: 'text/markdown' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'youtube-transcript-library.md';
  a.click();
  URL.revokeObjectURL(url);
});

diagnoseBtn.addEventListener('click', async () => {
  diagnosticResults.innerHTML = 'Opening a test tab and checking selectors…';
  diagnoseBtn.disabled = true;
  try {
    const response = await chrome.runtime.sendMessage({
      type: 'RUN_DIAGNOSTIC',
      platform: platformEl.value,
    });
    if (!response || response.error) {
      diagnosticResults.innerHTML = `<span class="ytr-diag-fail">Error: ${response?.error || 'unknown'}</span>`;
      return;
    }
    const rows = Object.entries(response.results || {})
      .map(([key, val]) => {
        if (val.ok === null) {
          return `<div class="ytr-diag-skip">${key}: N/A — ${val.note}</div>`;
        }
        const cls = val.ok ? 'ytr-diag-ok' : 'ytr-diag-fail';
        const label = val.ok
          ? `OK (${val.matchedSelector})`
          : `NOT FOUND${val.note ? ' — ' + val.note : ''}`;
        return `<div class="${cls}">${key}: ${label}</div>`;
      })
      .join('');
    diagnosticResults.innerHTML = rows || 'No results.';
  } catch (e) {
    diagnosticResults.innerHTML = `<span class="ytr-diag-fail">Error: ${e.message}</span>`;
  } finally {
    diagnoseBtn.disabled = false;
  }
});

load();
