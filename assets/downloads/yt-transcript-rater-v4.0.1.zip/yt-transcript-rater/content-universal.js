// content-universal.js — injected on demand (via chrome.scripting.executeScript
// using the activeTab permission) into the specific tab that submitted a
// "rate any link" job from the popup. Not declared in manifest.json content_scripts —
// it only ever runs in the one tab it was explicitly injected into, at the
// moment the user interacted with the extension. Never runs on arbitrary pages
// without that direct action.

(function () {
  if (window.__ytrUniversalInjected) return; // avoid double-injection
  window.__ytrUniversalInjected = true;

  function createUniversalButton() {
    if (document.getElementById('ytr-fab')) return { fab: document.getElementById('ytr-fab'), panel: document.getElementById('ytr-panel') };
    if (!document.body) return null;

    const fab = document.createElement('button');
    fab.id = 'ytr-fab';
    fab.title = "View this video's transcript rating";
    fab.textContent = '⭐';
    document.body.appendChild(fab);

    const panel = document.createElement('div');
    panel.id = 'ytr-panel';
    panel.style.display = 'none';
    document.body.appendChild(panel);

    return { fab, panel };
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message.type !== 'SHOW_RESULT_READY') return;

    const ui = createUniversalButton();
    if (!ui) return;
    const { fab, panel } = ui;

    fab.addEventListener('click', () => {
      panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    });

    if (message.error) {
      ytrRenderErrorWithFallback(panel, message.error, message.promptText);
    } else {
      ytrRenderResult(panel, message.result, message.meta, message.transcript);
    }

    // Show it once automatically so the user notices something arrived,
    // without needing to spot a small new button first.
    panel.style.display = 'block';
  });
})();
