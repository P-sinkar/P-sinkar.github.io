// Shared storage helper. Data shape kept intentionally simple and portable:
// {
//   folders: { [folderId]: { id, name, parentId } },   // parentId null = top level
//   chats:   { [chatId]:   { id, title, folderId, createTime } } // folderId null = Unorganized
// }

const STORE_KEY = "ccld_organizer_data_v1";

function emptyData() {
  return { folders: {}, chats: {} };
}

async function loadData() {
  const res = await chrome.storage.local.get(STORE_KEY);
  const data = res[STORE_KEY];
  if (!data) return emptyData();
  if (!data.folders) data.folders = {};
  if (!data.chats) data.chats = {};
  return data;
}

async function saveData(data) {
  await chrome.storage.local.set({ [STORE_KEY]: data });
}

function newId(prefix) {
  return prefix + "_" + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

// Extract a conversation id from a claude.ai URL, e.g.
// https://claude.ai/chat/6714e2b0-xxxx-xxxx-xxxx-xxxxxxxxxxxx
//
function extractConversationId(url) {
  if (!url) return null;
  const match = url.match(/\/chat\/([a-zA-Z0-9-]+)/);
  return match ? match[1] : null;
}

function isClaudeUrl(url) {
  return !!url && url.includes("claude.ai");
}

const LAST_BACKUP_KEY = "ccld_organizer_last_backup";

async function getLastBackupTime() {
  const res = await chrome.storage.local.get(LAST_BACKUP_KEY);
  return res[LAST_BACKUP_KEY] || null;
}

async function setLastBackupTime(ts) {
  await chrome.storage.local.set({ [LAST_BACKUP_KEY]: ts });
}

const PROJECT_PREFIXES_KEY = "ccld_organizer_project_prefixes";

async function getProjectPrefixes() {
  const res = await chrome.storage.local.get(PROJECT_PREFIXES_KEY);
  return Array.isArray(res[PROJECT_PREFIXES_KEY]) ? res[PROJECT_PREFIXES_KEY] : [];
}

async function setProjectPrefixes(list) {
  await chrome.storage.local.set({ [PROJECT_PREFIXES_KEY]: list });
}

const SORT_PREFS_KEY = "ccld_organizer_sort_prefs";
const DEFAULT_SORT_PREFS = { chatSort: "date_desc", folderSort: "name_asc" };

async function getSortPrefs() {
  const res = await chrome.storage.local.get(SORT_PREFS_KEY);
  return Object.assign({}, DEFAULT_SORT_PREFS, res[SORT_PREFS_KEY] || {});
}

async function setSortPrefs(prefs) {
  await chrome.storage.local.set({ [SORT_PREFS_KEY]: prefs });
}

const BACKUP_DISMISS_KEY = "ccld_organizer_backup_dismiss_until";

async function getBackupDismissUntil() {
  const res = await chrome.storage.local.get(BACKUP_DISMISS_KEY);
  return res[BACKUP_DISMISS_KEY] || 0;
}

async function setBackupDismissUntil(ts) {
  await chrome.storage.local.set({ [BACKUP_DISMISS_KEY]: ts });
}

// ---------- Full-conversation export ----------
// Three sources, tried in order by the organizer's export buttons:
//   1. fetchClaudeConversationViaPage — reads the conversation JSON from inside your open,
//      signed-in claude.ai tab, the same read the page does to display the chat. Read-only.
//      If Claude answers with an error instead of data, we just fall through to (2).
//   2. extractPageMessages — reads the rendered text off the open chat (or share) page.
//   3. Your official Claude data export (conversations.json) — slowest, always available.
// Sources 1 and 3 are both parsed by claudeConversationToMessages below.
//
// The JSON field names used here (chat_messages, sender, content blocks, parent_message_uuid,
// current_leaf_message_uuid, attachments/files) follow Claude's conversation format as
// widely documented by existing exporters — not yet confirmed against your account. The
// parser is defensive (accepts the older flat "text" field too), and the status line says
// which source was used, so a mismatch shows up immediately rather than silently.

function claudeBlockText(block, artifactTitles) {
  artifactTitles = artifactTitles || {};
  if (!block || typeof block !== "object") return "";
  if (block.type === "text") return (block.text || "").replace(/[\uE000-\uE002]/g, ""); // reserved for our markers
  if (block.type === "tool_use") {
    const inp = block.input || {};
    // Artifacts (documents, code, diagrams Claude wrote in the side panel).
    if (block.name === "artifacts") {
      if (inp.id && inp.title) artifactTitles[inp.id] = inp.title;
      const title = inp.title || artifactTitles[inp.id] || inp.id || "";
      if ((inp.command === "create" || inp.command === "rewrite") && inp.content) {
        const lang = inp.language || (/mermaid/.test(inp.type || "") ? "mermaid" : "");
        const isCode = inp.type === "application/vnd.ant.code" || /mermaid/.test(inp.type || "");
        const body = isCode ? "```" + lang + "\n" + inp.content + "\n```" : inp.content;
        return `\uE000${title}\uE001\n${body}\n\uE002`;
      }
      if (inp.command === "update" && (inp.new_str || inp.old_str)) {
        return `\uE000${title ? title + " (edit)" : "(edit)"}\uE001\nReplaced:\n${inp.old_str || ""}\n\nWith:\n${inp.new_str || ""}\n\uE002`;
      }
      return "";
    }
    // File-creation tools (newer Claude): keep the file body as a document.
    if ((block.name === "create_file" || block.name === "create") && (inp.file_text || inp.content)) {
      const name = (inp.path || inp.title || "").split("/").pop();
      return `\uE000${name}\uE001\n${inp.file_text || inp.content}\n\uE002`;
    }
    return ""; // web search, code execution input, etc.
  }
  return ""; // thinking, tool_result, images, etc.
}

function claudeConversationToMessages(conv) {
  const all = Array.isArray(conv && conv.chat_messages) ? conv.chat_messages : [];
  // Follow the branch you're actually looking at (edits/retries create side branches).
  let ordered = all;
  const byId = new Map(all.map(m => [m.uuid, m]));
  if (conv.current_leaf_message_uuid && byId.has(conv.current_leaf_message_uuid)) {
    const chain = [];
    const seen = new Set();
    let cur = byId.get(conv.current_leaf_message_uuid);
    while (cur && !seen.has(cur.uuid)) {
      seen.add(cur.uuid);
      chain.push(cur);
      cur = byId.get(cur.parent_message_uuid);
    }
    if (chain.length) ordered = chain.reverse();
  } else {
    ordered = [...all].sort((a, b) => (a.index ?? 0) - (b.index ?? 0) || String(a.created_at).localeCompare(String(b.created_at)));
  }

  const messages = [];
  const artifactTitles = {}; // artifact id → title, so later edits are labelled by name
  ordered.forEach(m => {
    const role = m.sender === "human" ? "user" : m.sender === "assistant" ? "assistant" : null;
    if (!role) return;
    let text = Array.isArray(m.content) && m.content.length
      ? m.content.map(b => claudeBlockText(b, artifactTitles)).filter(Boolean).join("\n\n")
      : (m.text || "").replace(/[\uE000-\uE002]/g, "");
    text = (text || "").trim();
    const names = [
      ...(m.attachments || []).map(a => a && (a.file_name || a.name)),
      ...(m.files || []).map(f => f && (f.file_name || f.name)),
      ...(m.files_v2 || []).map(f => f && (f.file_name || f.name))
    ].filter(Boolean);
    const attachments = [...new Set(names)];
    if (!text && !attachments.length) return;
    const t = m.created_at ? Date.parse(m.created_at) / 1000 : null;
    messages.push({ role, time: Number.isFinite(t) ? t : null, attachments, text });
  });
  return messages;
}

// Runs inside the open claude.ai tab (MAIN world, same session as the page itself).
async function fetchClaudeConversationViaPage(tabId, chatId) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      args: [chatId],
      func: async (id) => {
        try {
          const cookie = (name) => {
            const m = document.cookie.match(new RegExp("(?:^|; )" + name + "=([^;]*)"));
            return m ? decodeURIComponent(m[1]) : null;
          };
          const orgIds = [];
          const last = cookie("lastActiveOrg");
          if (last) orgIds.push(last);
          if (!orgIds.length) {
            const r = await fetch("/api/organizations", { credentials: "include" });
            if (!r.ok) return { ok: false, error: `organizations ${r.status}` };
            const orgs = await r.json();
            (Array.isArray(orgs) ? orgs : []).forEach(o => o && o.uuid && orgIds.push(o.uuid));
          }
          if (!orgIds.length) return { ok: false, error: "no organization found (not signed in?)" };

          let lastErr = "";
          for (const org of orgIds) {
            const url = `/api/organizations/${encodeURIComponent(org)}/chat_conversations/${encodeURIComponent(id)}?tree=True&rendering_mode=messages&render_all_tools=true`;
            const res = await fetch(url, { credentials: "include" });
            if (!res.ok) { lastErr = `conversation ${res.status}`; continue; }
            const json = await res.json();
            if (!json || !Array.isArray(json.chat_messages)) { lastErr = "unexpected response shape"; continue; }
            return { ok: true, data: json };
          }
          return { ok: false, error: lastErr || "not found" };
        } catch (e) {
          return { ok: false, error: String((e && e.message) || e) };
        }
      }
    });
    return results && results[0] ? results[0].result : { ok: false, error: "No result from page" };
  } catch (e) {
    return { ok: false, error: String((e && e.message) || e) };
  }
}

function isClaudeShareUrl(url) {
  return !!url && /claude\.ai\/share\//.test(url);
}

// Reads a public Claude share page directly — no auth wall to defeat, since these pages
// are designed to be viewable by anyone with the link.
//
// Selectors confirmed from real inspected markup — but from the live app, not the /share/
// page itself (the one open risk here, flagged honestly): user turns carry
// data-testid="user-message"; the assistant's rendered response text sits inside a
// data-cds="Prose" element. Both read as intentional identifiers (a test id, a named
// design-system component) rather than hashed build classes, so they're a safer bet than
// most alternatives — but if extraction stops working, that theory is the first thing to
// revisit, ideally against the actual /share/ page's markup.
//
// Uses textContent rather than innerText, same as the ChatGPT version and for the same
// reason: content-visibility optimizations on long messages can make innerText report
// empty/truncated text for portions not currently laid out on screen, even though they're
// present in the DOM. textContent reads the DOM directly regardless of render state.
async function extractPageMessages(tabId) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: async () => {
        try {
          const getFullText = (el) => {
            const clone = el.cloneNode(true);
            clone.querySelectorAll("script, style").forEach(n => n.remove());
            return (clone.textContent || "").trim();
          };

          const SEL = '[data-testid="user-message"], [data-cds="Prose"]';
          const countCandidates = () => document.querySelectorAll(SEL).length;

          // The transcript is virtualized — a "Load earlier messages" control and a large
          // spacer element were observed for older, unmounted turns. Try both a visible
          // trigger and scrolling to the top repeatedly, since it's unclear which one
          // actually drives the load, until the message count stops growing.
          const clickLoadEarlier = () => {
            const btn = Array.from(document.querySelectorAll("button"))
              .find(b => /load earlier messages/i.test(b.textContent || ""));
            if (btn) { btn.click(); return true; }
            return false;
          };

          const findScrollables = () =>
            Array.from(document.querySelectorAll("*")).filter(el => el.scrollHeight - el.clientHeight > 50);

          let scrollables = findScrollables();
          let lastCount = -1;
          let stableRounds = 0;
          for (let i = 0; i < 60 && stableRounds < 3; i++) {
            clickLoadEarlier();
            window.scrollTo(0, 0);
            scrollables.forEach(el => { el.scrollTop = 0; });
            await new Promise(r => setTimeout(r, 350));
            const count = countCandidates();
            if (count === lastCount) {
              stableRounds++;
            } else {
              stableRounds = 0;
              scrollables = findScrollables();
            }
            lastCount = count;
          }

          const dedupeTopLevel = nodes => nodes.filter(node => !nodes.some(other => other !== node && other.contains(node)));

          const nodes = dedupeTopLevel(Array.from(document.querySelectorAll(SEL)));
          const messages = nodes
            .map(el => ({
              role: el.getAttribute("data-testid") === "user-message" ? "user" : "assistant",
              text: getFullText(el)
            }))
            .filter(m => m.text);

          if (messages.length) return { ok: true, messages, count: messages.length, method: "testid/cds-attribute" };
          return { ok: false, error: "No message content found with the expected selectors." };
        } catch (e) {
          return { ok: false, error: String((e && e.message) || e) };
        }
      }
    });
    return results && results[0] ? results[0].result : { ok: false, error: "No result from page" };
  } catch (e) {
    return { ok: false, error: String((e && e.message) || e) };
  }
}

function safeFileName(name) {
  return (name || "chat").replace(/[\\/:*?"<>|]+/g, "_").trim().slice(0, 60) || "chat";
}

function downloadTextFile(filename, text, mimeType) {
  const blob = new Blob([text], { type: mimeType || "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// Browser tab titles for Claude are assumed to follow "<conversation title> - Claude" (or
// similar) — this specific suffix pattern hasn't been confirmed the way the /share/ URL and
// message selectors were, so it's worth checking your actual tab titles against this if
// titles come through with a stray suffix still attached. This relies only on the standard
// tabs API, not on scraping Claude's page DOM, so it doesn't break when they change their
// frontend markup.
//
// Claude also has Projects, which may prefix tab titles the same way ChatGPT Projects do
// ("<Project name> - <conversation title> - Claude") — unconfirmed, but the same safeguard
// applies either way: we can't safely guess which leading segment is a project name (some
// of your own chat titles may legitimately contain a dash), so projectPrefixes is an
// explicit, user-maintained list of exact project names to strip — deterministic, no risk
// of mangling an unrelated title.
function cleanTabTitle(rawTitle, projectPrefixes) {
  if (!rawTitle) return "Untitled";
  let cleaned = rawTitle.replace(/\s*[-|]\s*Claude\s*$/i, "").trim();

  if (Array.isArray(projectPrefixes)) {
    for (const raw of projectPrefixes) {
      const p = (raw || "").trim();
      if (!p) continue;
      for (const sep of [" - ", " \u2013 ", ": "]) {
        const prefix = p + sep;
        if (cleaned.startsWith(prefix)) {
          cleaned = cleaned.slice(prefix.length).trim();
          break;
        }
      }
    }
  }

  return cleaned || "Untitled";
}
