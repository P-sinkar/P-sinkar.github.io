let DATA = emptyData();
let SELECTED = { type: "all" }; // {type:'all'} | {type:'unorganized'} | {type:'folder', id}
let unorganizedCollapsed = false;
let CHAT_SORT = "date_desc";
let FOLDER_SORT = "name_asc";

function sortChats(chats) {
  const arr = chats.slice();
  switch (CHAT_SORT) {
    case "date_asc": arr.sort((a, b) => (a.createTime || 0) - (b.createTime || 0)); break;
    case "title_asc": arr.sort((a, b) => (a.title || "").localeCompare(b.title || "")); break;
    case "title_desc": arr.sort((a, b) => (b.title || "").localeCompare(a.title || "")); break;
    default: arr.sort((a, b) => (b.createTime || 0) - (a.createTime || 0)); // date_desc
  }
  return arr;
}

function chatsInFolder(folderId) {
  return Object.values(DATA.chats).filter(c => c.folderId === folderId);
}

function allChats() {
  return Object.values(DATA.chats);
}

function childFolders(parentId) {
  const arr = Object.values(DATA.folders).filter(f => f.parentId === parentId);
  if (FOLDER_SORT === "custom") {
    arr.sort((a, b) => (a.order || 0) - (b.order || 0));
  } else {
    arr.sort((a, b) => FOLDER_SORT === "name_desc" ? b.name.localeCompare(a.name) : a.name.localeCompare(b.name));
  }
  return arr;
}

function reorderFolder(draggedId, newParentId, targetId, zone) {
  DATA.folders[draggedId].parentId = newParentId;
  const siblings = Object.values(DATA.folders)
    .filter(f => f.parentId === newParentId && f.id !== draggedId)
    .sort((a, b) => (a.order || 0) - (b.order || 0));
  const targetIndex = siblings.findIndex(f => f.id === targetId);
  const insertAt = zone === "before" ? targetIndex : targetIndex + 1;
  siblings.splice(insertAt, 0, DATA.folders[draggedId]);
  siblings.forEach((f, i) => { f.order = i; });
}

function startFolderRename(nameEl, folder) {
  const input = document.createElement("input");
  input.type = "text";
  input.className = "inline-edit-input";
  input.value = folder.name || "";
  nameEl.replaceWith(input);
  input.focus();
  input.select();

  let settled = false;
  const commit = async () => {
    if (settled) return;
    settled = true;
    const val = input.value.trim();
    if (val) {
      folder.name = val;
      await persist();
    }
    renderAll();
  };
  const cancel = () => {
    if (settled) return;
    settled = true;
    renderAll();
  };

  input.addEventListener("keydown", (ev) => {
    if (ev.key === "Enter") { ev.preventDefault(); commit(); }
    else if (ev.key === "Escape") { ev.preventDefault(); cancel(); }
  });
  input.addEventListener("blur", commit);
}

function countInSubtree(folderId) {
  let count = chatsInFolder(folderId).length;
  childFolders(folderId).forEach(f => { count += countInSubtree(f.id); });
  return count;
}

function fmtDate(ts) {
  if (!ts) return "";
  const d = new Date(ts * 1000 > Date.now() * 2 ? ts : ts * 1000); // handle sec vs ms defensively
  if (isNaN(d.getTime())) return "";
  return d.toLocaleDateString();
}

async function persist() {
  await saveData(DATA);
}

// ---------- Tree rendering ----------

function renderTree() {
  const tree = document.getElementById("tree");
  tree.innerHTML = "";

  const sortRow = document.createElement("div");
  sortRow.className = "tree-sort-row";
  sortRow.innerHTML = `
    <select id="folderSortSelect">
      <option value="name_asc">Folders: A&ndash;Z</option>
      <option value="name_desc">Folders: Z&ndash;A</option>
      <option value="custom">Folders: Custom order</option>
    </select>
  `;
  tree.appendChild(sortRow);
  const folderSortSelect = sortRow.querySelector("select");
  folderSortSelect.value = FOLDER_SORT;
  folderSortSelect.addEventListener("change", async (e) => {
    FOLDER_SORT = e.target.value;
    await setSortPrefs({ chatSort: CHAT_SORT, folderSort: FOLDER_SORT });
    renderTree();
  });

  tree.appendChild(makeStaticRow("All chats", { type: "all" }, allChats().length, true));
  tree.appendChild(renderUnorganizedNode());

  const rootWrap = document.createElement("div");
  rootWrap.style.marginTop = "10px";
  childFolders(null).forEach(f => rootWrap.appendChild(renderFolderNode(f)));
  tree.appendChild(rootWrap);
}

function makeStaticRow(label, sel, count, acceptsFolderDrop) {
  const row = document.createElement("div");
  row.className = "folder-row" + (isSelected(sel) ? " active" : "");
  row.innerHTML = `<span>${label}</span><span class="count">${count}</span>`;
  row.addEventListener("click", () => { SELECTED = sel; renderAll(); });

  if (acceptsFolderDrop) {
    row.title = "Drop a folder here to move it to the top level";
    row.addEventListener("dragover", e => { e.preventDefault(); row.classList.add("drop-target"); });
    row.addEventListener("dragleave", () => row.classList.remove("drop-target"));
    row.addEventListener("drop", async e => {
      e.preventDefault();
      row.classList.remove("drop-target");
      const draggedFolderId = e.dataTransfer.getData("text/folder-id");
      if (draggedFolderId && DATA.folders[draggedFolderId]) {
        DATA.folders[draggedFolderId].parentId = null;
        await persist();
        renderAll();
      }
    });
  }

  return row;
}

function renderUnorganizedNode() {
  const node = document.createElement("div");
  const row = document.createElement("div");
  row.className = "folder-row" + (isSelected({ type: "unorganized" }) ? " active" : "");

  const chats = chatsInFolder(null);
  const hasChildren = chats.length > 0;
  const caret = hasChildren ? (unorganizedCollapsed ? "\u25B8" : "\u25BE") : "";

  row.innerHTML = `<span class="caret">${caret}</span><span>Unorganized</span><span class="count">${chats.length}</span>`;

  row.addEventListener("click", (e) => {
    if (e.target.classList.contains("caret") && hasChildren) {
      unorganizedCollapsed = !unorganizedCollapsed;
      renderTree();
      return;
    }
    SELECTED = { type: "unorganized" };
    renderAll();
  });

  row.addEventListener("dragover", e => { e.preventDefault(); row.classList.add("drop-target"); });
  row.addEventListener("dragleave", () => row.classList.remove("drop-target"));
  row.addEventListener("drop", async e => {
    e.preventDefault();
    row.classList.remove("drop-target");
    const chatId = e.dataTransfer.getData("text/chat-id");
    if (chatId && DATA.chats[chatId]) {
      DATA.chats[chatId].folderId = null;
      await persist();
      renderAll();
    }
  });

  node.appendChild(row);

  if (hasChildren && !unorganizedCollapsed) {
    const childWrap = document.createElement("div");
    childWrap.className = "folder-children";
    sortChats(chats).forEach(c => childWrap.appendChild(renderChatLeaf(c)));
    node.appendChild(childWrap);
  }

  return node;
}

function isSelected(sel) {
  if (sel.type !== SELECTED.type) return false;
  if (sel.type === "folder") return sel.id === SELECTED.id;
  return true;
}

function renderFolderNode(folder) {
  const node = document.createElement("div");
  node.className = "folder-node";

  const row = document.createElement("div");
  row.className = "folder-row" + (isSelected({ type: "folder", id: folder.id }) ? " active" : "");

  const kids = childFolders(folder.id);
  const folderChats = chatsInFolder(folder.id);
  const hasChildren = kids.length > 0 || folderChats.length > 0;
  const caret = hasChildren ? (folder.collapsed ? "\u25B8" : "\u25BE") : "";

  row.innerHTML = `
    <span class="caret">${caret}</span>
    <span class="name">${escapeHtml(folder.name)}</span>
    <span class="folder-actions">
      <span data-action="rename" title="Rename">\u270E</span>
      <span data-action="delete" title="Delete">\uD83D\uDDD1</span>
      <span data-action="add" title="Add subfolder">+</span>
    </span>
    <span class="count">${countInSubtree(folder.id)}</span>
  `;

  row.addEventListener("click", (e) => {
    if (e.target.dataset.action) return;
    if (e.target.classList.contains("caret") && hasChildren) {
      folder.collapsed = !folder.collapsed;
      persist();
      renderTree();
      return;
    }
    SELECTED = { type: "folder", id: folder.id };
    renderAll();
  });

  row.addEventListener("dragover", e => {
    e.preventDefault();
    const isFolderDrag = e.dataTransfer.types.includes("text/folder-id");
    row.classList.remove("drop-into", "drop-before", "drop-after");
    if (isFolderDrag) {
      const rect = row.getBoundingClientRect();
      const ratio = (e.clientY - rect.top) / rect.height;
      if (ratio < 0.25) { row.classList.add("drop-before"); row.dataset.dropZone = "before"; }
      else if (ratio > 0.75) { row.classList.add("drop-after"); row.dataset.dropZone = "after"; }
      else { row.classList.add("drop-into"); row.dataset.dropZone = "into"; }
    } else {
      row.classList.add("drop-into");
      row.dataset.dropZone = "into";
    }
  });
  row.addEventListener("dragleave", () => {
    row.classList.remove("drop-into", "drop-before", "drop-after");
    delete row.dataset.dropZone;
  });
  row.addEventListener("drop", async e => {
    e.preventDefault();
    const zone = row.dataset.dropZone || "into";
    row.classList.remove("drop-into", "drop-before", "drop-after");
    delete row.dataset.dropZone;

    const chatId = e.dataTransfer.getData("text/chat-id");
    const draggedFolderId = e.dataTransfer.getData("text/folder-id");

    if (chatId && DATA.chats[chatId]) {
      DATA.chats[chatId].folderId = folder.id;
      await persist();
      renderAll();
      return;
    }

    if (draggedFolderId && DATA.folders[draggedFolderId] && draggedFolderId !== folder.id) {
      const newParentId = zone === "into" ? folder.id : folder.parentId;
      if (newParentId && isWithinSubtree(newParentId, draggedFolderId)) {
        alert("Can't move a folder into itself or one of its own subfolders.");
        return;
      }
      if (zone === "into") {
        DATA.folders[draggedFolderId].parentId = newParentId;
        DATA.folders[draggedFolderId].order = Date.now();
      } else {
        reorderFolder(draggedFolderId, newParentId, folder.id, zone);
      }
      if (FOLDER_SORT !== "custom") {
        FOLDER_SORT = "custom";
        await setSortPrefs({ chatSort: CHAT_SORT, folderSort: FOLDER_SORT });
      }
      await persist();
      renderAll();
    }
  });

  row.draggable = true;
  row.addEventListener("dragstart", e => {
    e.dataTransfer.setData("text/folder-id", folder.id);
  });

  row.querySelector('[data-action="add"]').addEventListener("click", async (e) => {
    e.stopPropagation();
    const name = prompt("New subfolder name:");
    if (!name) return;
    const fid = newId("f");
    DATA.folders[fid] = { id: fid, name, parentId: folder.id, order: Date.now() };
    await persist();
    renderTree();
  });

  row.querySelector('[data-action="rename"]').addEventListener("click", (e) => {
    e.stopPropagation();
    startFolderRename(row.querySelector(".name"), folder);
  });

  row.querySelector('[data-action="delete"]').addEventListener("click", async (e) => {
    e.stopPropagation();
    if (!confirm(`Delete "${folder.name}" and its subfolders? Chats inside will move to Unorganized.`)) return;
    deleteFolderRecursive(folder.id);
    if (SELECTED.type === "folder" && SELECTED.id === folder.id) SELECTED = { type: "all" };
    await persist();
    renderAll();
  });

  node.appendChild(row);

  if (hasChildren && !folder.collapsed) {
    const childWrap = document.createElement("div");
    childWrap.className = "folder-children";
    kids.forEach(f => childWrap.appendChild(renderFolderNode(f)));
    sortChats(folderChats).forEach(c => childWrap.appendChild(renderChatLeaf(c)));
    node.appendChild(childWrap);
  }

  return node;
}

function renderChatLeaf(chat) {
  const row = document.createElement("div");
  row.className = "tree-chat-leaf";
  row.draggable = true;
  row.innerHTML = `
    <span class="leaf-title">${chat.titleLocked ? "\uD83D\uDD12 " : ""}${escapeHtml(chat.title || "Untitled")}</span>
    <span class="leaf-actions">
      ${chat.folderId ? '<span data-action="unassign" title="Move to Unorganized">\u00D7</span>' : ""}
      <span data-action="edit" title="Edit title">\u270E</span>
      <span data-action="remove" title="Remove from organizer (does not delete the chat on Claude)">\uD83D\uDDD1</span>
    </span>
  `;

  row.querySelector(".leaf-title").addEventListener("click", async (e) => {
    const url = `https://claude.ai/chat/${chat.id}`;
    if (e.ctrlKey || e.metaKey) {
      chrome.tabs.create({ url });
      return;
    }
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (activeTab) chrome.tabs.update(activeTab.id, { url });
    else chrome.tabs.create({ url });
  });

  const unassignBtn = row.querySelector('[data-action="unassign"]');
  if (unassignBtn) {
    unassignBtn.addEventListener("click", async (e) => {
      e.stopPropagation();
      chat.folderId = null;
      await persist();
      renderAll();
    });
  }

  row.querySelector('[data-action="edit"]').addEventListener("click", (e) => {
    e.stopPropagation();
    startInlineEdit(row.querySelector(".leaf-title"), chat, renderAll);
  });

  row.querySelector('[data-action="remove"]').addEventListener("click", async (e) => {
    e.stopPropagation();
    if (!confirm(`Remove "${chat.title || "Untitled"}" from the organizer? This only stops tracking it here — it won't touch the actual chat on Claude.`)) return;
    delete DATA.chats[chat.id];
    await persist();
    renderAll();
  });

  row.addEventListener("dragstart", e => {
    e.dataTransfer.setData("text/chat-id", chat.id);
  });

  return row;
}

function isWithinSubtree(candidateId, rootId) {
  // true if candidateId is rootId itself, or a descendant of rootId
  let current = candidateId;
  while (current) {
    if (current === rootId) return true;
    current = DATA.folders[current] ? DATA.folders[current].parentId : null;
  }
  return false;
}

function deleteFolderRecursive(folderId) {
  childFolders(folderId).forEach(f => deleteFolderRecursive(f.id));
  Object.values(DATA.chats).forEach(c => { if (c.folderId === folderId) c.folderId = null; });
  delete DATA.folders[folderId];
}

function escapeHtml(s) {
  const div = document.createElement("div");
  div.textContent = s;
  return div.innerHTML;
}

// Swaps a title span for an inline text input (avoids window.prompt(), which is
// unreliable inside extension popups/side panels). Enter saves, Escape cancels, blur saves.
function startInlineEdit(titleEl, chatRecord, onDone) {
  const input = document.createElement("input");
  input.type = "text";
  input.className = "inline-edit-input";
  input.value = chatRecord.title || "";
  titleEl.replaceWith(input);
  input.focus();
  input.select();

  let settled = false;
  const commit = async () => {
    if (settled) return;
    settled = true;
    const val = input.value.trim();
    if (val) {
      chatRecord.title = val;
      chatRecord.titleLocked = true;
      await persist();
    }
    onDone();
  };
  const cancel = () => {
    if (settled) return;
    settled = true;
    onDone();
  };

  input.addEventListener("keydown", (ev) => {
    if (ev.key === "Enter") { ev.preventDefault(); commit(); }
    else if (ev.key === "Escape") { ev.preventDefault(); cancel(); }
  });
  input.addEventListener("blur", commit);
}

// ---------- Chat list rendering ----------

function renderChatList() {
  const container = document.getElementById("chatList");
  container.innerHTML = "";

  const query = document.getElementById("searchBox").value.trim().toLowerCase();

  let chats;
  if (query) {
    chats = allChats().filter(c => (c.title || "").toLowerCase().includes(query));
  } else if (SELECTED.type === "all") {
    chats = allChats();
  } else if (SELECTED.type === "unorganized") {
    chats = chatsInFolder(null);
  } else {
    chats = chatsInFolder(SELECTED.id);
  }

  chats = sortChats(chats);

  if (!chats.length) {
    container.innerHTML = '<div class="empty-state">No chats here yet. Drag chats onto a folder, or import your Claude export.</div>';
    return;
  }

  chats.forEach(c => {
    const item = document.createElement("div");
    item.className = "chat-item";
    item.draggable = true;
    item.innerHTML = `
      <span class="title">${c.titleLocked ? '<span class="lock-badge" title="Title locked \u2014 won\'t auto-update from the browser tab">\uD83D\uDD12</span> ' : ""}${escapeHtml(c.title || "Untitled")}</span>
      <span>
        <span class="date">${fmtDate(c.createTime)}</span>
        ${c.folderId ? '<span class="unassign" title="Move to Unorganized">move to Unorganized</span>' : ""}
        <span class="edit-link" title="Edit title">edit title</span>
        ${c.titleLocked ? '<span class="unlock-link" title="Allow auto-sync from the browser tab again">unlock</span>' : ""}
        <span class="remove-link" title="Remove from organizer (does not delete the chat on Claude)">remove</span>
      </span>
    `;
    item.querySelector(".title").addEventListener("click", async (e) => {
      const url = `https://claude.ai/chat/${c.id}`;
      if (e.ctrlKey || e.metaKey) {
        // Ctrl/Cmd+click still opens a new tab, matching normal browser link behavior
        chrome.tabs.create({ url });
        return;
      }
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (activeTab) {
        chrome.tabs.update(activeTab.id, { url });
      } else {
        chrome.tabs.create({ url });
      }
    });
    const unassign = item.querySelector(".unassign");
    if (unassign) {
      unassign.addEventListener("click", async (e) => {
        e.stopPropagation();
        c.folderId = null;
        await persist();
        renderAll();
      });
    }
    item.querySelector(".edit-link").addEventListener("click", (e) => {
      e.stopPropagation();
      startInlineEdit(item.querySelector(".title"), c, renderAll);
    });
    const unlockLink = item.querySelector(".unlock-link");
    if (unlockLink) {
      unlockLink.addEventListener("click", async (e) => {
        e.stopPropagation();
        c.titleLocked = false;
        await persist();
        renderAll();
      });
    }
    item.querySelector(".remove-link").addEventListener("click", async (e) => {
      e.stopPropagation();
      if (!confirm(`Remove "${c.title || "Untitled"}" from the organizer? This only stops tracking it here — it won't touch the actual chat on Claude.`)) return;
      delete DATA.chats[c.id];
      await persist();
      renderAll();
    });
    item.addEventListener("dragstart", e => {
      e.dataTransfer.setData("text/chat-id", c.id);
    });
    container.appendChild(item);
  });
}

function renderAll() {
  renderTree();
  renderChatList();
}

// ---------- Import / Export ----------
// ---------- Import from Claude's official data export ----------
// Claude: Settings → Privacy → Export data. The emailed zip contains conversations.json —
// a list of conversations with uuid / name / created_at. Only those three fields are used
// here; your folder assignments are never touched. Re-importing refreshes titles.

document.getElementById("importBtn").addEventListener("click", () => {
  document.getElementById("importFile").click();
});

document.getElementById("importFile").addEventListener("change", async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  e.target.value = "";
  let parsed;
  try {
    parsed = JSON.parse(await file.text());
  } catch (err) {
    showImportStatus("Could not parse that file as JSON. Use the conversations.json from your Claude data export.", true);
    return;
  }

  const list = Array.isArray(parsed) ? parsed : (parsed.conversations || []);
  let added = 0, titlesUpdated = 0, unchanged = 0, skipped = 0;

  list.forEach(conv => {
    const id = conv && (conv.uuid || conv.id);
    if (!id) { skipped++; return; }
    const title = (conv.name || conv.title || "").trim() || "Untitled";
    const t = Date.parse(conv.created_at || conv.updated_at || "");
    const createTime = Number.isFinite(t) ? t / 1000 : 0;
    const existing = DATA.chats[id];

    if (existing) {
      if (existing.title !== title) { existing.title = title; titlesUpdated++; } else { unchanged++; }
      existing.titleLocked = true; // export title is authoritative — protect it from tab-title sync
      if (!existing.createTime && createTime) existing.createTime = createTime;
      return; // never touches folderId
    }
    DATA.chats[id] = { id, title, folderId: null, createTime, titleLocked: true };
    added++;
  });

  if (!added && !titlesUpdated && !unchanged) {
    showImportStatus(`No conversations found in that file${skipped ? ` (${skipped} entries had no id)` : ""}. Make sure it's conversations.json from Claude's data export, not this extension's own backup.`, true);
    return;
  }
  await persist();
  showImportStatus(`Imported ${added} new chat${added === 1 ? "" : "s"}, refreshed ${titlesUpdated} title${titlesUpdated === 1 ? "" : "s"}, ${unchanged} unchanged.`);
  SELECTED = { type: "unorganized" };
  renderAll();
});

function showImportStatus(msg, isError) {
  const el = document.getElementById("importStatus");
  el.textContent = msg;
  el.style.display = "block";
  el.style.background = isError ? "#fdeaea" : "#eaf7ea";
  el.style.color = isError ? "#8a1a1a" : "#1a5c1a";
}

document.getElementById("exportBtn").addEventListener("click", async () => {
  const blob = new Blob([JSON.stringify(DATA, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `claude-organizer-backup-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
  await setLastBackupTime(Date.now());
  document.getElementById("backupReminder").style.display = "none";
});

document.getElementById("restoreBtn").addEventListener("click", () => {
  document.getElementById("restoreFile").click();
});

document.getElementById("restoreFile").addEventListener("change", async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const text = await file.text();
  let backup;
  try {
    backup = JSON.parse(text);
  } catch (err) {
    showImportStatus("Could not parse that file — expected a claude-organizer-backup-*.json file from Export backup.", true);
    return;
  }

  if (!backup || typeof backup !== "object" || !backup.folders || !backup.chats) {
    showImportStatus("That file doesn't look like a valid backup (missing folders/chats).", true);
    return;
  }

  const isEmpty = Object.keys(DATA.folders).length === 0 && Object.keys(DATA.chats).length === 0;
  if (!isEmpty && !confirm(
    "You already have folders/chats saved. Restoring will add anything from the backup that's missing, " +
    "without overwriting your current folder assignments. Continue?"
  )) return;

  let foldersAdded = 0, chatsAdded = 0;
  Object.values(backup.folders).forEach(f => {
    if (!DATA.folders[f.id]) { DATA.folders[f.id] = f; foldersAdded++; }
  });
  Object.values(backup.chats).forEach(c => {
    if (!DATA.chats[c.id]) { DATA.chats[c.id] = c; chatsAdded++; }
  });

  await persist();
  showImportStatus(`Restored ${foldersAdded} folder(s) and ${chatsAdded} chat(s) from backup.`);
  renderAll();
  e.target.value = "";
});

document.getElementById("syncTabsBtn").addEventListener("click", async () => {
  const tabs = await chrome.tabs.query({});
  const projectPrefixes = await getProjectPrefixes();
  let updated = 0, added = 0;

  tabs.forEach(tab => {
    if (!isClaudeUrl(tab.url)) return;
    const chatId = extractConversationId(tab.url);
    if (!chatId) return;

    const title = cleanTabTitle(tab.title, projectPrefixes);
    const existing = DATA.chats[chatId];

    if (existing) {
      if (!existing.titleLocked && existing.title !== title) {
        existing.title = title;
        updated++;
      }
    } else {
      DATA.chats[chatId] = { id: chatId, title, folderId: null, createTime: Date.now() / 1000 };
      added++;
    }
  });

  await persist();
  showImportStatus(`Synced open tabs: updated ${updated} title${updated === 1 ? "" : "s"}, added ${added} new chat${added === 1 ? "" : "s"} to Unorganized.`);
  renderAll();
});

// ---------- Export current chat (two formats) ----------
// "For AI" → .md for pasting/uploading into another LLM or program.
// "Readable" → self-contained .html for people.
let pendingExport = null; // { chatId, format, meta } waiting on the export-file picker

function deliverExport(format, messages, meta) {
  const base = safeFileName(meta.title);
  if (format === "ai") {
    downloadTextFile(`${base} (for AI).md`, messagesToAiMarkdown(messages, meta), "text/markdown");
  } else {
    downloadTextFile(`${base}.html`, messagesToHtml(messages, meta), "text/html");
  }
}

function formatLabel(format) { return format === "ai" ? "AI-ready .md" : "readable .html"; }

async function exportCurrentChat(format) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab || !isClaudeUrl(tab.url)) {
    showImportStatus("Switch to an open Claude chat (or a share link) in this window first, then export.", true);
    return;
  }

  const projectPrefixes = await getProjectPrefixes();
  const title = cleanTabTitle(tab.title, projectPrefixes);
  const meta = { title, url: tab.url.split("?")[0], source: "Claude" };

  // Public share page: read the rendered page.
  if (isClaudeShareUrl(tab.url)) {
    showImportStatus("Reading the shared conversation...");
    const result = await extractPageMessages(tab.id);
    if (!result.ok) {
      showImportStatus(`Couldn't read this share page (${result.error}).`, true);
      return;
    }
    deliverExport(format, result.messages, { ...meta, completeness: "partial" });
    showImportStatus(`Downloaded ${formatLabel(format)} for "${title}" (${result.messages.length} messages, via share page).`);
    return;
  }

  const chatId = extractConversationId(tab.url);
  if (!chatId) {
    showImportStatus("That tab doesn't look like a Claude conversation (expected claude.ai/chat/…) — open an actual chat first.", true);
    return;
  }

  // 1. Full conversation JSON, read from inside the open tab — complete, no Share needed.
  showImportStatus("Reading this conversation...");
  const direct = await fetchClaudeConversationViaPage(tab.id, chatId);
  if (direct.ok) {
    const messages = claudeConversationToMessages(direct.data);
    if (messages.length) {
      const t = (direct.data.name || "").trim() || title;
      deliverExport(format, messages, { ...meta, title: t, completeness: "full" });
      showImportStatus(`Downloaded ${formatLabel(format)} for "${t}" (${messages.length} messages, full conversation).`);
      return;
    }
  }

  // 2. Fall back to the text rendered on the open page.
  const fromPage = await extractPageMessages(tab.id);
  if (fromPage.ok) {
    deliverExport(format, fromPage.messages, { ...meta, completeness: "partial" });
    showImportStatus(`Downloaded ${formatLabel(format)} for "${title}" (${fromPage.messages.length} messages, read from the page — full read unavailable: ${direct.error || "empty"}). Artifacts and very long replies may be incomplete.`, true);
    return;
  }

  // 3. Last resort: the official export file.
  pendingExport = { chatId, format, meta };
  showImportStatus(`Couldn't read this chat directly (${direct.error || "empty"}; page: ${fromPage.error}). Select your Claude export (conversations.json) to pull the full text of "${title}".`, true);
  document.getElementById("exportChatFile").click();
}

document.getElementById("exportAiBtn").addEventListener("click", () => exportCurrentChat("ai"));
document.getElementById("exportHtmlBtn").addEventListener("click", () => exportCurrentChat("html"));

document.getElementById("exportChatFile").addEventListener("change", async (e) => {
  const file = e.target.files[0];
  e.target.value = "";
  if (!file || !pendingExport) return;

  const { chatId, format, meta } = pendingExport;
  pendingExport = null;

  let parsed;
  try {
    parsed = JSON.parse(await file.text());
  } catch (err) {
    showImportStatus("Could not parse that file as JSON. Use the conversations.json from your Claude data export.", true);
    return;
  }

  const list = Array.isArray(parsed) ? parsed : (parsed.conversations || []);
  const match = list.find(c => (c.uuid || c.id) === chatId);
  if (!match) {
    showImportStatus(`"${meta.title}" isn't in that export yet — export fresh data from Claude (Settings → Privacy → Export data) and try again.`, true);
    return;
  }

  const messages = claudeConversationToMessages(match);
  deliverExport(format, messages, { ...meta, completeness: "full" });
  showImportStatus(`Downloaded ${formatLabel(format)} for "${meta.title}" (${messages.length} messages).`);
});

document.getElementById("projectPrefixesBtn").addEventListener("click", async () => {
  const current = (await getProjectPrefixes()).join("\n");
  const input = prompt(
    "Claude project names to strip from chat titles (one per line, exact match, case-sensitive):",
    current
  );
  if (input === null) return; // cancelled
  const list = input.split("\n").map(s => s.trim()).filter(Boolean);
  await setProjectPrefixes(list);
  showImportStatus(`Saved ${list.length} project name${list.length === 1 ? "" : "s"}. Re-open a chat's popup or click "Sync open tabs" to apply it to already-known titles.`);
});

document.getElementById("expandAllBtn").addEventListener("click", async () => {
  Object.values(DATA.folders).forEach(f => { f.collapsed = false; });
  await persist();
  renderTree();
});

document.getElementById("collapseAllBtn").addEventListener("click", async () => {
  Object.values(DATA.folders).forEach(f => { f.collapsed = true; });
  await persist();
  renderTree();
});

document.getElementById("newFolderBtn").addEventListener("click", async () => {
  const name = prompt("New folder name:");
  if (!name) return;
  const fid = newId("f");
  DATA.folders[fid] = { id: fid, name, parentId: null, order: Date.now() };
  await persist();
  renderAll();
});

document.getElementById("searchBox").addEventListener("input", renderChatList);

document.getElementById("chatSortSelect").addEventListener("change", async (e) => {
  CHAT_SORT = e.target.value;
  await setSortPrefs({ chatSort: CHAT_SORT, folderSort: FOLDER_SORT });
  renderAll();
});

// ---------- Backup reminder ----------

const BACKUP_REMINDER_DAYS = 14;

async function checkBackupReminder() {
  const el = document.getElementById("backupReminder");
  const hasData = Object.keys(DATA.folders).length > 0 || Object.keys(DATA.chats).length > 0;
  if (!hasData) { el.style.display = "none"; return; }

  const dismissUntil = await getBackupDismissUntil();
  if (dismissUntil && Date.now() < dismissUntil) { el.style.display = "none"; return; }

  const last = await getLastBackupTime();
  const daysSince = last ? (Date.now() - last) / (1000 * 60 * 60 * 24) : Infinity;

  if (daysSince < BACKUP_REMINDER_DAYS) { el.style.display = "none"; return; }

  const msg = last
    ? `It's been ${Math.floor(daysSince)} days since your last backup.`
    : "You haven't exported a backup yet.";
  el.innerHTML = `<span>${msg} Your folder organization only lives in this browser.</span><span><button id="backupNowBtn">Export backup now</button> <button id="backupLaterBtn" class="dismiss-btn">Not now</button></span>`;
  el.style.display = "flex";
  document.getElementById("backupNowBtn").addEventListener("click", () => {
    document.getElementById("exportBtn").click();
  });
  document.getElementById("backupLaterBtn").addEventListener("click", async () => {
    await setBackupDismissUntil(Date.now() + 3 * 24 * 60 * 60 * 1000); // snooze 3 days
    el.style.display = "none";
  });
}

// ---------- Init ----------

(async function init() {
  DATA = await loadData();
  const sortPrefs = await getSortPrefs();
  CHAT_SORT = sortPrefs.chatSort;
  FOLDER_SORT = sortPrefs.folderSort;
  document.getElementById("chatSortSelect").value = CHAT_SORT;
  renderAll();
  checkBackupReminder();
})();
