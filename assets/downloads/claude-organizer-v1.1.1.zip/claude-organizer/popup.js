function folderPathOptions(folders) {
  // Build indented list: [{id, label}], root first, depth via indentation
  const byParent = {};
  Object.values(folders).forEach(f => {
    const key = f.parentId || "root";
    (byParent[key] = byParent[key] || []).push(f);
  });
  const out = [];
  function walk(parentKey, depth) {
    const kids = (byParent[parentKey] || []).sort((a, b) => a.name.localeCompare(b.name));
    kids.forEach(f => {
      out.push({ id: f.id, label: "\u00A0\u00A0".repeat(depth) + f.name });
      walk(f.id, depth + 1);
    });
  }
  walk("root", 0);
  return out;
}

async function render() {
  const content = document.getElementById("content");
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const url = tab ? tab.url : null;

  if (!isClaudeUrl(url)) {
    content.innerHTML = '<div class="not-chat">Open a Claude tab to quick-assign it to a folder.</div>';
    return;
  }

  const chatId = extractConversationId(url);
  if (!chatId) {
    content.innerHTML = '<div class="not-chat">Open a specific conversation (a chat with messages) to assign it — this looks like a new/empty chat.</div>';
    return;
  }

  const data = await loadData();
  const existing = data.chats[chatId];
  const projectPrefixes = await getProjectPrefixes();
  const title = cleanTabTitle(tab.title, projectPrefixes);

  // Passive title sync: if this chat is already filed and its title on the page has
  // changed (you renamed it in Claude), pick that up automatically — but never for a
  // locked title (set by import or a manual edit), since the browser tab title is not
  // reliable for chats inside a Claude Project (it gets prefixed with the project name).
  if (existing && !existing.titleLocked && existing.title !== title) {
    existing.title = title;
    await saveData(data);
  }

  const options = folderPathOptions(data.folders);
  const optionsHtml = ['<option value="">Unorganized</option>']
    .concat(options.map(o => `<option value="${o.id}">${o.label}</option>`))
    .join("");

  content.innerHTML = `
    <div class="row">
      <div class="chat-title">${title}</div>
      <div class="muted">${existing ? "Currently: " + (data.folders[existing.folderId] ? data.folders[existing.folderId].name : "Unorganized") : "Not yet saved"}</div>
    </div>
    <div class="row">
      <select id="folderSelect">${optionsHtml}</select>
    </div>
    <div class="row">
      <input id="newFolderName" placeholder="Or type a new folder name" />
    </div>
    <button id="saveBtn">Save to folder</button>
    <div id="savedMsg" class="assigned" style="display:none;">Saved.</div>
  `;

  if (existing) {
    document.getElementById("folderSelect").value = existing.folderId || "";
  }

  document.getElementById("saveBtn").addEventListener("click", async () => {
    const fresh = await loadData();
    let folderId = document.getElementById("folderSelect").value || null;
    const newName = document.getElementById("newFolderName").value.trim();

    if (newName) {
      const fid = newId("f");
      fresh.folders[fid] = { id: fid, name: newName, parentId: null };
      folderId = fid;
    }

    fresh.chats[chatId] = fresh.chats[chatId]
      ? Object.assign({}, fresh.chats[chatId], { folderId })
      : { id: chatId, title, folderId, createTime: Date.now() / 1000 };

    await saveData(fresh);
    document.getElementById("savedMsg").style.display = "block";
  });
}

document.getElementById("openOrganizer").addEventListener("click", async () => {
  const win = await chrome.windows.getCurrent();
  await chrome.sidePanel.open({ windowId: win.id });
  window.close();
});

render();
